/******************************************************************************
* toupclt.c
*
* Copyright �1997-2000, BEA Systems, Inc., all rights reserved.
*/


/* Identification */

#if defined(__STDC__) || defined(__cplusplus)
static const char	toupclt_c_id[] =
    "@(#)SNA $Header: /repos/tma/sample/snasnt/toupclt.c,v 1.1 2014/02/19 05:29:01 xixisun Exp $   ";
#endif

/* System includes */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <atmi.h>	/* TUXEDO  Header File */
#include <userlog.h>	/* TUXEDO Header File */


#if defined(__STDC__) || defined(__cplusplus)
void error_end (char *sendbuf, char *rcvbuf, long intrans);
#else
void error_end ();
#endif


/*
  returns n for -n type options
  sets global myoptarg to value associated
  with -n. myoptarg wll be incorrect for
  opts which do not have an arg.
  caller should ignore value
*/
static char *myoptarg = 0;
static char *mynxtarg = 0;
#if defined(__STDC__) || defined(__cplusplus)
int optget(int ct, char * cl[])
#else
int optget(ct, cl)
int ct;
char * cl[];
#endif
{
  int argct = 0;
  int opt   = 0;
  for(argct++;argct < ct;argct++)
    {
      if((char)*(cl[argct]) == (char)'-')
        {
          *(cl[argct]) = (char)' ';
          myoptarg = cl[argct+1];
          mynxtarg = cl[argct+2];
          opt = (char)*((cl[argct])+1);
          return opt;
        }
    }
  return -1;
}


#if defined(__STDC__) || defined(__cplusplus)
int main(int argc, char *argv[])
#else
int main(argc, argv)
int argc;
char *argv[];
#endif
{

        char** tmpArgv = argv;
	char *sendbuf, *rcvbuf;
	long sendlen, rcvlen;
	int ret, c = 0;
        long sync_level = 0;
        char test_type [3];
	char tranname [8];
 
	       /*  service name is SIMP concatenated to test type */		   
	strcpy (tranname,"SIMP");    
	strcpy (test_type,"DPL");    /* set default test type to DPL */
	 
	mynxtarg = argv[argc - 1]; 
/*      while ((c = getopt(argc, tmpArgv, "s:l:t:h")) != -1) */
        while ((c = optget(argc, tmpArgv)) != -1)
        {
            switch(c)
            {
              case 't' :
		strcpy(test_type, myoptarg);
		break;
              case 's' :
              case 'l' :
		sync_level = strtol(myoptarg, (char**)NULL, 0);
		break;
              case 'h' :
		printf("\nUsage is:\n");
		printf("%6.6s -s n 		[Sync Level (default=%d)]\n", argv[0], sync_level);
		printf("       -t xxx       	[Test Type (default=%3.3s)]\n", test_type);
		printf("       -h   		[Help]\n\n");
                exit(1);
	    default:
		fprintf(stderr, "Invalid option -%c\n", c);
                exit(1);
	    } 
        }

/*      if (optind + 1 > argc) {   */
        if (mynxtarg == NULL || argc < 2) {
		fprintf(stderr, "String is required\n");
		exit(1);
	}
  
	/* Attach to System/T as a Client Process */
	if (tpinit((TPINIT *) NULL) == -1) {
		fprintf(stderr, "Tpinit failed\n");
		exit(1);
	}
	
        /* If transactional then perform tpbegin            */
        if (sync_level)  
           if (( ret = tpbegin (0, 0)) == -1) {
		userlog("Failed to start transaction\n");
		userlog("Error %s\n", tpstrerror(tperrno));
                error_end (NULL, NULL, 0);
           }
   
	/* Allocate STRING buffers for the request and the reply */

/*      sendlen = strlen (argv [optind]); */
        sendlen = strlen (mynxtarg);

	if((sendbuf = (char *) tpalloc("STRING", NULL, sendlen+1)) == NULL) {
		userlog("Error allocating send buffer\n");
                error_end (sendbuf, NULL, sync_level);
	}

	if((rcvbuf = (char *) tpalloc("STRING", NULL, sendlen+1)) == NULL) {
		userlog("Error allocating receive buffer\n");
		error_end (sendbuf, rcvbuf, sync_level);
	}

/*	strcpy(sendbuf, argv[optind]); */
	strcpy(sendbuf, mynxtarg);
	
        strcat(tranname, test_type);

	/* Request the service TOUPPER, waiting for a reply */
	ret = tpcall(tranname, sendbuf, 0, &rcvbuf, &rcvlen, TPNOTIME);

	if(ret == -1) {
		userlog("Can't send request to service %s\n", tranname);
		userlog("Error %s\n", tpstrerror(tperrno));
		error_end (sendbuf, rcvbuf, sync_level);
	}

	printf("Returned string is(%d): %s\n", rcvlen, rcvbuf);

	/* Free Buffers & Detach from System/T */
	tpfree(sendbuf);
	tpfree(rcvbuf);
    
	if(sync_level) {
		/* sleep(30);	trigger Trans MIRR RTIMOUT */
		ret = tpcommit(0); 
		if(ret == -1)
			fprintf(stderr, "Error commit %s\n", tpstrerror(tperrno));
	}
	tpterm();

	exit(0);
}


#if defined(__STDC__) || defined(__cplusplus)
void error_end (char *sendbuf, char *rcvbuf, long intrans)  
#else
void error_end (sendbuf, rcvbuf, intrans)  
char *sendbuf;
char *rcvbuf;
long intrans;
#endif
 {

   fprintf (stderr, "Error encountered by Toupper client\n");  
   fprintf (stderr, "See UserLog for details\n");  
   if (sendbuf != NULL) {
      tpfree(sendbuf);
      if (rcvbuf != NULL)
         tpfree (rcvbuf);
   } 
   if (intrans)
      tpabort (0);
   tpterm ();
   exit (1);
}

/* End toupclt.c */

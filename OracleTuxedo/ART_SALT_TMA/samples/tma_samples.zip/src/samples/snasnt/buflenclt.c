/*=====================================================================*/
/* Client zviewcln Requests Service(VIEW$$) From Server ZVIEWSRV On IBM*/
/*=====================================================================*/
#include <stdio.h>          /* UNIX */
#include <string.h>         /* UNIX */
#include <time.h>          /* UNIX */
/*#include <decimal.h>*/      /* TUXEDO */
#include <atmi.h>           /* TUXEDO */
#include <userlog.h>        /* TUXEDO */
#ifdef _TMFML32
#include <fml32.h>          /* TUXEDO */
#include <fml1632.h>        /* TUXEDO */
#else
#include <fml.h>            /* TUXEDO */
#include <Usysflds.h>       /* TUXEDO */
#endif
#include "bufview.h"        /* VIEW32 */
#include "buffml.h"

/* we use a generic structure since all 
** the views used have the same layout */
/*---------------------------------------------------------------------*/

/*---------------------------------------------------------------------*/
#define CX_PROGRAM  ((FLDID32)231327331)            /* number: 30000739  type: carray */
#define CX_TRANSID  ((FLDID32)231327333)            /* number: 30000741  type: carray */
#define CX_CHANNEL_NAME ((FLDID32)231329593)        /* number: 30003001  type: carray */
#define CX_CONTAINER_NAME   ((FLDID32)231329594)    /* number: 30003002  type: carray */
#define CX_CONTAINER_DATA   ((FLDID32)231329595)    /* number: 30003003  type: carray */

#define LEN_PROGRAM 30  /* GWSNAX gives 30 spaces pad for ARTDPL */
#define LEN_TRANSID 4
#define LEN_CHANNAME 16
#define LEN_CONTNAME 16

/* Non-aligned view, needs -fpack-struct=1 flag in make */
/* #pragma pack(push, 1) */
#include "chanview.h"

void disp(char *head, struct flat *pvw)
{
	int i;

	printf("%s:\n", head);
	printf("CH(%c)\n", pvw->Ach);
	printf("SH(%d)\n",  pvw->Bsh);
	printf("STR(%.40s)\n",  pvw->Cstr);
	printf("LO(%ld)\n",  pvw->Dlo);
	printf("CA(");
	for(i = 0; i < sizeof(pvw->Eca); i ++)
		printf("%02x", (unsigned char)pvw->Eca[i]);
	printf(")\n");
}

void disp1(char *head, struct lenft *pvw)
{
	int i;

	printf("%s:\n", head);
	printf("CH(%c)\n", pvw->Ach);
	printf("SH(%d)\n",  pvw->Bsh);
	printf("STR(%.40s)\n",  pvw->Cstr);
}
sendcarray(char *svc)
{
	char txt[32];
	int rc;
	int cd;
	long len;
	long revent;
	char* req;
	//char* resp;
	struct lenft *resp;
			

	len = 256;
  	req = tpalloc("CARRAY", NULL, len);
	if(req == NULL) {
        fprintf(stderr, "tpalloc %s failed (%s)\n", txt, tpstrerror(tperrno));
		return -1;
  	}
  	memset(req, 0, len);
/*
  	resp = tpalloc("CARRAY", NULL, len);
	if(resp == NULL) {
        fprintf(stderr, "tpalloc %s failed (%s)\n", txt, tpstrerror(tperrno));
		return -1;
  	}
  	memset(resp, 0, len);
*/
	char ach[1];
	ach[1] = '1';
	short bsh = 98;
	memcpy(req, &ach[1], 1);
    memcpy(req+1, &bsh, sizeof(short));
	strcpy(req+3, svc);

	len = 1+sizeof(short)+strlen(svc)+1;

	cd = tpconnect(svc, (char *)req, len, TPRECVONLY | TPSIGRSTRT);
	if(cd == -1) {
		fprintf(stderr, "Tpconnect failed: %s\n", tpstrerror(tperrno));
  		tpfree((char *)req);
		return -1;
	}

	printf("Send(%d)\n", len);
	printf("CH(%c)\n", req[0]);
	printf("SH(%d)\n",  bsh);
	printf("STR(%.40s)\n", req+3);

  	strcpy(txt, "lenft");
  	resp = (struct lenft*)tpalloc("VIEW32", txt, sizeof(struct lenft));
	if(resp == NULL) {
        fprintf(stderr, "tpalloc %s failed (%s)\n", txt, tpstrerror(tperrno));
		return -1;
  	}
  	memset(resp, 0, sizeof(struct lenft));

	while(1) {
		rc = tprecv(cd, (char **)&resp, &len, TPSIGRSTRT, &revent);
		if(rc == -1) {
			if(tperrno != TPEEVENT) {
				fprintf(stderr, "Tprecv failed: %s\n", tpstrerror(tperrno));
				tpdiscon(cd);
  				tpfree((char *)req);
  				tpfree((char *)resp);
				return -1;
			}
			if(revent == TPEV_SVCSUCC) {
				break;
			} else {
				fprintf(stderr, "Tprecv recieved an unexpected event 0x%x. \n" , revent);
				tpdiscon(cd);
  				tpfree((char *)req);
  				tpfree((char *)resp);
				return -1;
			}
		}
		else
			printf("rc(%d)\n", rc);
	}

	sprintf(txt, "Recv(%d)", len);
  	disp1(txt, (struct lenft*)resp);
  	tpfree((char *)req);
  	tpfree((char *)resp);

	return 0;
}

void dspBuffer(char *title, int len, struct container1 *data)
{
	char tmp[80];
	int i;

	printf("%s(%d)\n", title, len);
	printf("CH(%c)\n", data->ach);
	printf("INT(%ld)\n",  data->bint);
	printf("STR(%.40s)\n", data->cstr);
	printf("LO(%ld)\n", data->dlo32);
	for(i = 0; i < sizeof(data->eca); i ++)
		sprintf(tmp + 2 * i, "%02x", (unsigned char)data->eca[i]);
	printf("CA(%.40s)\n", tmp);
	printf("FI(%.10s ...) \n", data->ffi);
}


int putBuffer(char *svcnm, int num, int apdflg, int times, FBFR32 *pfb)
{
	char channame[LEN_CHANNAME + 1];
	char contname[LEN_CONTNAME + 1];
	int i, j, k;
	int rc;
	struct container1 data;
	int len = 0;

	strcpy(channame, "MYCHAN");
	rc = Fadd32(pfb, CX_CHANNEL_NAME, channame, strlen(channame));
	if(rc == -1) {
		fprintf(stderr, "add chanName %s\n", Fstrerror32(Ferror32));
		return(-1);
	}
	printf("\n%04d PUT %s(%d)\n", times, channame, num);
	for(i = 0; i < num; i ++) {
		memset(&data, 0, sizeof(struct container1));
		data.ach = i + '1';
		data.bint = sizeof(struct container1) - sizeof(data.ffi);
		strcpy(data.cstr, svcnm);
		data.dlo32 = -999999999;
		memset(data.eca, 0x01, sizeof(data.eca));
		if(apdflg) {
			//data.bint = sizeof(struct container1);
			data.bint = 1220 + i*100;
/* add tag to buffer */
			memset(data.ffi, ' ', sizeof(data.ffi) - 1);
			for(j = 0; j < sizeof(data.ffi); j += 1000) {
				k = j / 1000 + 1;
				data.ffi[j] = '0' + k / 10;
				data.ffi[j + 1] = '0' + k % 10;
			}
			data.ffi[sizeof(data.ffi) - 2] = '9';
		}
		
		sprintf(contname, "CONTAINER%c", data.ach);
		rc = Fadd32(pfb, CX_CONTAINER_NAME, contname, strlen(contname));
		if(rc == -1) {
			fprintf(stderr, "add contName %s\n", Fstrerror32(Ferror32));
			return(-1);
		}
		/*
		if ( i == 1) 
			rc = Fadd32(pfb, CX_CONTAINER_DATA, (char *)&data, 30 sizeof(struct container1));
		else 
				*/
		len = 1220 + i*100;
		rc = Fadd32(pfb, CX_CONTAINER_DATA, (char *)&data, len);

		len = 0;
		char* flddata = Ffind32((FBFR32 *)pfb, CX_CONTAINER_DATA, i, &len);
		/*
		printf("CONTAINER LEN(%d)", len);
		userlog("CONTAINER LEN(%d)", len);
*/
		if(rc == -1) {
				fprintf(stderr, "add contData %s\n", Fstrerror32(Ferror32));
				return(-1);
		}

		dspBuffer(contname, len, &data);
	}
	printf("\n");

	return(0);
}

int getBuffer(int times, FBFR32 *pfb)
{
	char channame[LEN_CHANNAME + 1];
	char contname[LEN_CONTNAME + 1];
	char *p;
	int rc, oc, i;
	struct container1 contdata1;
	struct container2 contdata2;
	struct container3 contdata3;
	FLDLEN32 len;

	len = sizeof(channame);
	rc = Fget32(pfb, CX_CHANNEL_NAME, 0, channame, &len);
	if(rc == -1) {
		fprintf(stderr, "get chanName %s\n", Fstrerror32(Ferror32));
		return(-1);
	}
	channame[len] = 0;
	
	oc = Foccur32(pfb, CX_CONTAINER_NAME);
	if(oc == -1) {
		fprintf(stderr, "occur contName %s\n", Fstrerror32(Ferror32));
		return(-1);
	}
	printf("%04d GET %s(%d)\n", times, channame, oc);

	for(i = 0; i < oc; i ++) {
		len = sizeof(contname);
		rc = Fget32(pfb, CX_CONTAINER_NAME, i, contname, &len);
		if(rc == -1) {
			fprintf(stderr, "get contName failed %s\n", Fstrerror32(Ferror32));
			return(-1);
		}
		contname[len] = 0;
		if(0 == strcasecmp(contname, "container1"))
			p = (char *)&contdata1;
		else if(0 == strcasecmp(contname, "container2"))
			p = (char *)&contdata2;
		else if(0 == strcasecmp(contname, "container3"))
			p = (char *)&contdata3;
		else {
			fprintf(stderr, "unknown container\n");
			return(-1);
		}

/* Handle 3 containers in same way */
		len = sizeof(struct container1);
		rc = Fget32(pfb, CX_CONTAINER_DATA, i, p, &len);
		if(rc == -1) {
			fprintf(stderr, "get contData %s\n", Fstrerror32(Ferror32));
			return(-1);
		}
		dspBuffer(contname, len, (struct container1 *)p);
	}
	printf("\n");

	return(0);
}


int sendvarchan(char* svcnm, int sync_lv)
{
		int i, rc;
		int times = 1;
		FBFR32 *pfb;
		int cont_num = 3;
		int has_append = 1;

		long olen;

		for(i = 0; i < times; i ++) {
				pfb = (FBFR32 *)tpalloc("FML32", NULL, 1024 * 128);
				if(pfb == NULL) {
						fprintf(stderr, "tpalloc %s\n", tpstrerror(tperrno));
						tpterm();
						exit(-1);
				}

				rc = putBuffer(svcnm, cont_num, has_append, i + 1, pfb);
				if(rc == -1){
						tpfree((char *)pfb);
						if(sync_lv)
								tpabort(0);
						tpterm();
						exit(-1);
				}

				rc = tpcall(svcnm, (char *)pfb, 0, (char **)&pfb, &olen, TPNOTIME);
				if(rc == -1){
						fprintf(stderr, "tpcall %s\n", tpstrerror(tperrno));
						tpfree((char *)pfb);
						if(sync_lv)
								tpabort(0);
						tpterm();
						exit(-1);
				}

				rc = getBuffer(i + 1, pfb);
				if(rc == -1){
						tpfree((char *)pfb);
						if(sync_lv)
								tpabort(0);
						tpterm();
						exit(-1);
				}

				tpfree((char *)pfb);
		}


}


main(int argc, char *argv[])
{
	int rc;
	int sync;

	if(argc < 3) {
		printf("Usage: %s 0|2 service\n", argv[0]);
		exit(1);
	}

	sync = atoi(argv[1]);
	if(sync != 0 && sync != 2) {
		printf("Usage: %s 0|2 service\n", argv[0]);
		exit(1);
	}

    if(tpinit((TPINIT *)NULL) == -1) {
        (void)fprintf(stderr, "Failed to join application  -- %s\n",
            tpstrerror(tperrno));
        (void)userlog("%s failed to join the application  -- %s\n",
            argv[0], tpstrerror(tperrno));
        (void)exit(1);
    }

    //struct container1* resp = (struct container1*)tpalloc("VIEW32", "container1", sizeof(struct container1));
	//printf("sizeof struct container1(%d)\n", sizeof(struct container1));

	if(sync == 2)
		tpbegin(0, 0);

	if (!strcmp(argv[2], "DTP_KVA6"))
		rc = sendcarray(argv[2]);
	else if (!strcmp(argv[2], "KNCO"))
		rc = sendvarchan(argv[2], sync);
    else 
        printf("service name is not valid\n");
	if(rc == -1 && sync == 2 && tpabort(0) == -1) {
		(void)fprintf(stderr, "Tpabort failed: %s\n", tpstrerror(tperrno));
		(void)userlog("%s tpabort failed: %s\n", argv[0], tpstrerror(tperrno));
		(void)exit(1);
	}


//    struct lsr_input_parms * resp = (struct lsr_input_parms*)tpalloc("VIEW32", "lsr_input_parms", sizeof(struct lsr_input_parms));

/*
	rc = sendvarchan(argv[2], sync);
	if(rc == -1 && sync == 2 && tpabort(0) == -1) {
		(void)fprintf(stderr, "Tpabort failed: %s\n", tpstrerror(tperrno));
		(void)userlog("%s tpabort failed: %s\n", argv[0], tpstrerror(tperrno));
		(void)exit(1);
	}
*/
	if(sync == 2 && tpcommit(0) == -1) {
		(void)fprintf(stderr, "Tpcommit failed: %s\n", tpstrerror(tperrno));
		(void)userlog("%s tpcommit failed: %s\n", argv[0], tpstrerror(tperrno));
		(void)exit(1);
	}

	(void)tpterm();
	(void)exit(0);
}

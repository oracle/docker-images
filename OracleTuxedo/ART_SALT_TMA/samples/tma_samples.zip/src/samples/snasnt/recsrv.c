/*	(c) 2003 BEA Systems, Inc. All Rights Reserved. */
/*	Copyright (c) 1997 BEA Systems, Inc.
  	All rights reserved

  	THIS IS UNPUBLISHED PROPRIETARY
  	SOURCE CODE OF BEA Systems, Inc.
  	The copyright notice above does not
  	evidence any actual or intended
  	publication of such source code.
*/

/* #ident	"@(#) samples/atmi/simpapp/simpserv.c	$Revision: 1.2 $" */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <atmi.h>	/* TUXEDO Header File */
#include <userlog.h>	/* TUXEDO Header File */

#include "bufview.h"
#include "buffml.h"

/* tpsvrinit is executed when a server is booted, before it begins
   processing requests.  It is not necessary to have this function.
   Also available is tpsvrdone (not used in this example), which is
   called at server shutdown time.
*/

int
#if defined(__STDC__) || defined(__cplusplus)
tpsvrinit(int argc, char *argv[])
#else
tpsvrinit(argc, argv)
int argc;
char **argv;
#endif
{
	/* Some compilers warn if argc and argv aren't used. */

	/* userlog writes to the central TUXEDO message log */
	userlog("Welcome to the simple server");
	return(0);
}

/* This function performs the actual service requested by the client.
   Its argument is a structure containing among other things a pointer
   to the data buffer, and the length of the data buffer.
*/


void disp(char *head, struct flat *pvw)
{
	char tmp[80];
	int i;

	userlog("%s:\n", head);
	userlog("CH(%c)\n", pvw->Ach);
	userlog("SH(%d)\n",  pvw->Bsh);
	userlog("STR(%.40s)\n", pvw->Cstr);
	userlog("LO(%ld)\n", pvw->Dlo);
	for(i = 0; i < sizeof(pvw->Eca); i ++)
		sprintf(tmp + 2 * i, "%02x", (unsigned char)pvw->Eca[i]);
	userlog("CA(%.40s)\n", tmp);
}

void reverse(char *str, int beg, int end)
{
	char c;
   
	if(beg >= end)
		return;   

	c = *(str + beg);
    *(str + beg) = *(str + end);
	*(str + end) = c;
	reverse(str, ++ beg, -- end);
}

#ifdef __cplusplus
extern "C"
#endif
void
#if defined(__STDC__) || defined(__cplusplus)
RECVIEW(TPSVCINFO *rqst)
#else
RECVIEW(rqst)
TPSVCINFO *rqst;
#endif
{
	struct flat *req;
	struct flat1 *resp;
	char txt[40];
	int i;

	req = (struct flat *)rqst->data;

	sprintf(txt, "Recv(%d)", rqst->len);
	disp(txt, (struct flat *)req);

	strcpy(txt, "flat1");
  	resp = (struct flat1 *)tpalloc("VIEW32", txt, sizeof(struct flat1));
	if(resp == NULL) {
		userlog("tpalloc %s failed (%s)\n", txt, tpstrerror(tperrno));
		tpreturn(TPFAIL, tperrno, NULL, 0L, 0);
  	}
	memset(resp, 0, sizeof(struct flat1));
	memcpy(resp, req, sizeof(struct flat));
	resp->Ach += ('a' - '1');
	resp->Bsh = sizeof(struct flat1);
	strcpy(resp->Cstr, rqst->name);
	resp->Dlo ++;
	for(i = 0; i < sizeof(resp->Eca); i ++)
		resp->Eca[i] = i;
	memset(resp->Ffi, ' ', sizeof(resp->Ffi) - 1);
	memcpy(resp->Ffi, "1234567890", 10);
	memcpy(resp->Ffi + sizeof(resp->Ffi) - 11, "1234567890", 10);

	sprintf(txt, "Send(%d)", resp->Bsh);
	disp(txt, (struct flat *)resp);

	/* Return the transformed buffer to the requestor. */
	tpreturn(TPSUCCESS, 0, (char *)resp, 0L, 0);
}

#ifdef __cplusplus
extern "C"
#endif
void
#if defined(__STDC__) || defined(__cplusplus)
RECFML(TPSVCINFO *rqst)
#else
RECFML(rqst)
TPSVCINFO *rqst;
#endif
{
	char txt[40];
	struct flat *pvw;
	FBFR32 *req;
	FBFR32 *resp;
	FLDLEN32 flen;
	int i;
	char fi[32001];

	req = (FBFR32 *)rqst->data;

  	strcpy(txt, "flat");
  	pvw = (struct flat *)tpalloc("VIEW32", txt, sizeof(struct flat));
	if(pvw == NULL) {
        userlog("tpalloc %s failed (%s)\n", txt, tpstrerror(tperrno));
		tpreturn(TPFAIL, tperrno, NULL, 0L, 0);
  	}
  	memset(pvw, 0, sizeof(struct flat));
	
	if(Fvftos32(req, (char *)pvw, txt) == -1) {
    	userlog("Fvftos32 failed (%s)\n", tpstrerror(tperrno));
		tpreturn(TPFAIL, tperrno, NULL, 0L, 0);
  	} 
	sprintf(txt, "Recv(%d)", rqst->len);
  	disp(txt, (struct flat *)pvw);

	resp = (FBFR32 *)tpalloc("FML32", NULL, 32600); 
	if(resp == NULL) {
		userlog("tpcalloc FML32 failed (%s)\n", tpstrerror(tperrno));
		tpreturn(TPFAIL, tperrno, NULL, 0L, 0);
	}

	pvw->Ach += ('a' - '1');
	Fchg32(resp, ACH, 0, (char *)&(pvw->Ach), 0);
	pvw->Bsh = Fsizeof32(resp);
	Fchg32(resp, BSH, 0, (char *)&(pvw->Bsh), 0);
	strcpy(pvw->Cstr, rqst->name);
	Fchg32(resp, CSTR, 0, pvw->Cstr, 0);
	pvw->Dlo ++;
	Fchg32(resp, DLO, 0, (char *)&(pvw->Dlo), 0);
	for(i = 0; i < sizeof(pvw->Eca); i ++)
		pvw->Eca[i] = i;
	Fchg32(resp, ECA, 0, pvw->Eca, sizeof(pvw->Eca));
	memset(fi, 0, sizeof(fi));
	memset(fi, ' ', sizeof(fi) - 1);
	memcpy(fi, "1234567890", 10);
	memcpy(fi + sizeof(fi) - 11, "1234567890", 10);
	Fchg32(resp, FFI, 0, fi, 0);

	sprintf(txt, "Send(%d)", pvw->Bsh);
	disp(txt, (struct flat *)pvw);

	/* Return the transformed buffer to the requestor. */
	tpreturn(TPSUCCESS, 0, (char *)resp, 0L, 0);
}

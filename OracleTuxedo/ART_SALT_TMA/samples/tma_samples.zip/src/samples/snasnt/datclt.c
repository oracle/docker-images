/*=====================================================================*/
/* Client zviewcln Requests Service(VIEW$$) From Server ZVIEWSRV On IBM*/
/*=====================================================================*/
#include <stdio.h>          /* UNIX */
#include <string.h>         /* UNIX */
#include <time.h>           /* UNIX */
#include <atmi.h>           /* TUXEDO */
#include <decimal.h>        /* TUXEDO */
#include <userlog.h>        /* TUXEDO */
#ifdef _TMFML32
#include <fml32.h>          /* TUXEDO */
#include <fml1632.h>        /* TUXEDO */
#else
#include <fml.h>            /* TUXEDO */
#include <Usysflds.h>       /* TUXEDO */
#endif
#include "datview.h"        /* VIEW32 */
/* we use a generic structure since all 
** the views used have the same layout */
/*---------------------------------------------------------------------*/
void disp(char *text, struct datvw *pvw)
{
	int i;
	double d;

	printf("%s:\n", text);
	printf("CH(%c)\n", pvw->Ach);
	printf("SH(%d)\n",  pvw->Bsh);
	printf("STR(%.40s)\n",  pvw->Cstr);
	printf("LO(%ld)\n",  pvw->Dlo32);
	printf("CA(");
	for(i = 0; i < sizeof(pvw->Eca); i ++)
		printf("%02x", (unsigned char)pvw->Eca[i]);
	printf(")\n");
	printf("ZO(%.7s)\n",  pvw->Fzo);
	printf("FL(%f)\n",  pvw->Gfl);
	printf("DO(%e)\n",  pvw->Hdo);
	dectodbl(&(pvw->Ide), &d);
	printf("DE(%e)\n", d);
}

datview(char *svc)
{
	char txt[32];
	struct datvw *req;
	long len;

  	strcpy(txt, "datvw");
  	req = (struct datvw *)tpalloc("VIEW32", txt, sizeof(struct datvw));
	if(req == NULL) {
        printf("tpalloc %s failed (%s)\n", txt, tpstrerror(tperrno));
		return(-1);
  	}
  	memset(req, 0, sizeof(struct datvw));
    req->Ach = '1';
    req->Bsh = sizeof(struct datvw);
    strcpy(req->Cstr, svc);
	req->Dlo32 = 999999999;
	memset(req->Eca, 1, sizeof(req->Eca));
	strcpy(req->Fzo, "1234567");
	req->Gfl = 1234567.89;
	req->Hdo = -1234567.89;
	deccvdbl(1234567.89, &(req->Ide));

	printf("%s:\n", svc);
	disp("Send", req);
	printf("\n");

  	if(tpcall(svc, (char *)req, 0L, (char **)&req, &len, TPNOTIME) == -1) {
		printf("tpcall %s failed (%s)\n", svc, tpstrerror(tperrno)); 
		return(-1);
    }

	sprintf(txt, "Recv(%ld)", len);
  	disp(txt, req);

  	tpfree((char *)req);
	return(0);
}


/*---------------------------------------------------------------------*/
main(int argc, char *argv[])
{
    if(tpinit((TPINIT *)NULL) == -1) {
        (void)fprintf(stderr, "Failed to join application  -- %s\n",
            tpstrerror(tperrno));
        (void)userlog("%s failed to join the application  -- %s\n",
            argv[0], tpstrerror(tperrno));
        (void)exit(1);
    }

	datview("DATVIEW");
	
	tpterm();

	exit(0);
}

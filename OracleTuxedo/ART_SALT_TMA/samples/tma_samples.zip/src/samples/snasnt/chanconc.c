#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <atmi.h>	/* TUXEDO Header File */
#include <userlog.h>	/* TUXEDO Header File */

#define	CX_PROGRAM	((FLDID32)231327331)	        /* number: 30000739	 type: carray */
#define	CX_TRANSID	((FLDID32)231327333)	        /* number: 30000741	 type: carray */
#define	CX_CHANNEL_NAME	((FLDID32)231329593)    	/* number: 30003001	 type: carray */
#define	CX_CONTAINER_NAME	((FLDID32)231329594)	/* number: 30003002	 type: carray */
#define	CX_CONTAINER_DATA	((FLDID32)231329595)	/* number: 30003003	 type: carray */

#define LEN_PROGRAM 30	/* GWSNAX gives 30 spaces pad for ARTDPL */
#define LEN_TRANSID 4
#define LEN_CHANNAME 16
#define LEN_CONTNAME 16

/* Non-aligned view, needs -fpack-struct=1 flag in make */
/* #pragma pack(push, 1) */
#include "chanview.h"
/* #pragma pack(pop) */
/* Non-aligned view */

static char *myoptarg = 0;
static char *mynxtarg = 0;

int getOpt(int ct, char *cl[])
{
	int i;
	int opt = 0;

	for(i = 1; i < ct; i ++) {
		if((char)*(cl[i]) == (char)'-') {
			*(cl[i]) = (char)' ';
			myoptarg = cl[i + 1];
			mynxtarg = cl[i + 2];
			opt = (char)*((cl[i]) + 1);
			return opt;
		}
	}

	return -1;
}

void usage(char *name)
{
	printf("Usage: %s "
		"[-n contNum(1-3)] "
		"[-s syncLv(0|1)] "
		"[-a hasAppend(0|1)] "
		"[-t times(1-1000)] "
		"svcNm\n",
	   	name);
}

void dspBuffer(char *title, int len, struct container1 *data)
{
	char tmp[80];
	int i;

	printf("%s(%d)\n", title, len);
	printf("CH(%c)\n", data->ach);
	printf("INT(%ld)\n",  data->bint);
	printf("STR(%.40s)\n", data->cstr);
	printf("LO(%ld)\n", data->dlo32);
	for(i = 0; i < sizeof(data->eca); i ++)
		sprintf(tmp + 2 * i, "%02x", (unsigned char)data->eca[i]);
	printf("CA(%.40s)\n", tmp);
	printf("FI(%.10s ... %.10s)\n", data->ffi, data->ffi + sizeof(data->ffi) - 11);
}

int putBuffer(char *svcnm, int num, int apdflg, int times, FBFR32 *pfb)
{
	char channame[LEN_CHANNAME + 1];
	char contname[LEN_CONTNAME + 1];
	int i, j, k;
	int rc;
	struct container1 data;

	strcpy(channame, "MYCHAN");
	rc = Fadd32(pfb, CX_CHANNEL_NAME, channame, strlen(channame));
	if(rc == -1) {
		fprintf(stderr, "add chanName %s\n", Fstrerror32(Ferror32));
		return(-1);
	}
	printf("\n%04d PUT %s(%d)\n", times, channame, num);

	for(i = 0; i < num; i ++) {
		memset(&data, 0, sizeof(struct container1));
		data.ach = i + '1';
		data.bint = sizeof(struct container1) - sizeof(data.ffi);
		strcpy(data.cstr, svcnm);
		data.dlo32 = -999999999;
		memset(data.eca, 0x01, sizeof(data.eca));
		if(apdflg) {
			data.bint = sizeof(struct container1);
/* add tag to buffer */
			memset(data.ffi, ' ', sizeof(data.ffi) - 1);
			for(j = 0; j < sizeof(data.ffi); j += 1000) {
				k = j / 1000 + 1;
				data.ffi[j] = '0' + k / 10;
				data.ffi[j + 1] = '0' + k % 10;
			}
			data.ffi[sizeof(data.ffi) - 2] = '9';
		}
		
		sprintf(contname, "CONTAINER%c", data.ach);
		rc = Fadd32(pfb, CX_CONTAINER_NAME, contname, strlen(contname));
		if(rc == -1) {
			fprintf(stderr, "add contName %s\n", Fstrerror32(Ferror32));
			return(-1);
		}

		rc = Fadd32(pfb, CX_CONTAINER_DATA, (char *)&data, sizeof(struct container1));
		if(rc == -1) {
			fprintf(stderr, "add contData %s\n", Fstrerror32(Ferror32));
			return(-1);
		}

		dspBuffer(contname, sizeof(struct container1), &data);
	}
	printf("\n");

	return(0);
}

int getBuffer(int times, FBFR32 *pfb)
{
	char channame[LEN_CHANNAME + 1];
	char contname[LEN_CONTNAME + 1];
	char *p;
	int rc, oc, i;
	struct container1 contdata1;
	struct container2 contdata2;
	struct container3 contdata3;
	FLDLEN32 len;

	len = sizeof(channame);
	rc = Fget32(pfb, CX_CHANNEL_NAME, 0, channame, &len);
	if(rc == -1) {
		fprintf(stderr, "get chanName %s\n", Fstrerror32(Ferror32));
		return(-1);
	}
	channame[len] = 0;
	
	oc = Foccur32(pfb, CX_CONTAINER_NAME);
	if(oc == -1) {
		fprintf(stderr, "occur contName %s\n", Fstrerror32(Ferror32));
		return(-1);
	}
	printf("%04d GET %s(%d)\n", times, channame, oc);

	for(i = 0; i < oc; i ++) {
		len = sizeof(contname);
		rc = Fget32(pfb, CX_CONTAINER_NAME, i, contname, &len);
		if(rc == -1) {
			fprintf(stderr, "get contName failed %s\n", Fstrerror32(Ferror32));
			return(-1);
		}
		contname[len] = 0;
		if(0 == strcasecmp(contname, "container1"))
			p = (char *)&contdata1;
		else if(0 == strcasecmp(contname, "container2"))
			p = (char *)&contdata2;
		else if(0 == strcasecmp(contname, "container3"))
			p = (char *)&contdata3;
		else {
			fprintf(stderr, "unknown container\n");
			return(-1);
		}

/* Handle 3 containers in same way */
		len = sizeof(struct container1);
		rc = Fget32(pfb, CX_CONTAINER_DATA, i, p, &len);
		if(rc == -1) {
			fprintf(stderr, "get contData %s\n", Fstrerror32(Ferror32));
			return(-1);
		}
		dspBuffer(contname, len, (struct container1 *)p);
	}
	printf("\n");

	return(0);
}

main(int argc, char **argv)
{
	char svcnm[17];
	int i, rc;
	int c = 0;
	int sync_lv = 0;
	int cont_num = 1;
	int has_append = 0;
	int times = 1;
	long olen;
	FBFR32 *pfb;

	mynxtarg = argv[argc - 1]; 
    while((c = getOpt(argc, argv)) != -1) {
		switch(c) {
			case 'n' :
				cont_num = strtol(myoptarg, (char **)NULL, 0);
				break;
			case 's' :
				sync_lv = strtol(myoptarg, (char **)NULL, 0);
				break;
			case 'a' :
				has_append = strtol(myoptarg, (char **)NULL, 0);
				break;
			case 't' :
				times = strtol(myoptarg, (char **)NULL, 0);
				break;
			default:
				usage(argv[0]);
				exit(1);
		}
	}
	if(argc < 2 || mynxtarg == NULL ||
		(cont_num < 1 || cont_num > 3) ||
		(sync_lv < 0 || sync_lv > 1) ||
		(has_append < 0 || has_append > 1) ||
		(times < 1 || times > 1000))
	{
		usage(argv[0]);
		exit(1);
	}

	strcpy(svcnm, mynxtarg);
/*
	printf("cont_num(%d)sync_lv(%d)has_append(%d)svcnm(%s)\n",
	   	cont_num, sync_lv, has_append, svcnm);
*/

	rc = tpinit((TPINIT *)NULL);
	if(rc == -1) {
		fprintf(stderr, "tpinit %s\n", tpstrerror(tperrno));
		exit(-1);
	}

	if (sync_lv && tpbegin (0, 0) == -1) {
		fprintf(stderr, "tpbegin %s\n", tpstrerror(tperrno));
		tpfree((char *)pfb);
		tpterm();
		exit(-1);
	}

	for(i = 0; i < times; i ++) {
		pfb = (FBFR32 *)tpalloc("FML32", NULL, 1024 * 128);
		if(pfb == NULL) {
			fprintf(stderr, "tpalloc %s\n", tpstrerror(tperrno));
			tpterm();
			exit(-1);
		}

		rc = putBuffer(svcnm, cont_num, has_append, i + 1, pfb);
		if(rc == -1){
			tpfree((char *)pfb);
			if(sync_lv)
				tpabort(0);
			tpterm();
			exit(-1);
		}
	
		rc = tpcall(svcnm, (char *)pfb, 0, (char **)&pfb, &olen, TPNOTIME);
		if(rc == -1){
			fprintf(stderr, "tpcall %s\n", tpstrerror(tperrno));
			tpfree((char *)pfb);
			if(sync_lv)
				tpabort(0);
			tpterm();
			exit(-1);
		}
	
		rc = getBuffer(i + 1, pfb);
		if(rc == -1){
			tpfree((char *)pfb);
			if(sync_lv)
				tpabort(0);
			tpterm();
			exit(-1);
		}

		tpfree((char *)pfb);
	}

	if(sync_lv && tpcommit(0) == -1) {
		fprintf(stderr, "tpcommit %s\n", tpstrerror(tperrno));
		tpterm();
		exit(-1);
	}

	tpterm();
	exit(0);
}

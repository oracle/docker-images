
/*	(c) 2003 BEA Systems, Inc. All Rights Reserved. */
/*	Copyright (c) 1997 BEA Systems, Inc.
  	All rights reserved

  	THIS IS UNPUBLISHED PROPRIETARY
  	SOURCE CODE OF BEA Systems, Inc.
  	The copyright notice above does not
  	evidence any actual or intended
  	publication of such source code.
*/

/* #ident	"@(#) samples/atmi/simpapp/simpserv.c	$Revision: 1.9 $" */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <atmi.h>	/* TUXEDO Header File */
#include <userlog.h>	/* TUXEDO Header File */

#define	CX_PROGRAM	((FLDID32)231327331)	        /* number: 30000739	 type: carray */
#define	CX_TRANSID	((FLDID32)231327333)	        /* number: 30000741	 type: carray */
#define	CX_CHANNEL_NAME	((FLDID32)231329593)    	/* number: 30003001	 type: carray */
#define	CX_CONTAINER_NAME	((FLDID32)231329594)	/* number: 30003002	 type: carray */
#define	CX_CONTAINER_DATA	((FLDID32)231329595)	/* number: 30003003	 type: carray */

#define LEN_PROGRAM 30	/* GWSNAX gives 30 spaces pad for ARTDPL */
#define LEN_TRANSID 4
#define LEN_CHANNAME 16
#define LEN_CONTNAME 16

/* Non-aligned view, needs -fpack-struct=1 flag in make */
/* #pragma pack(push, 1) */
#include "chanview.h"
/* #pragma pack(pop) */
/* Non-aligned view */

/* tpsvrinit is executed when a server is booted, before it begins
   processing requests.  It is not necessary to have this function.
   Also available is tpsvrdone (not used in this example), which is
   called at server shutdown time.
*/

static int get_usec(void)
{
	struct timeval tv;

	gettimeofday(&tv, NULL);
/*
	userlog("%ld %ld", tv.tv_sec, tv.tv_usec);
*/
	return(tv.tv_usec);
}

int
#if defined(__STDC__) || defined(__cplusplus)
tpsvrinit(int argc, char *argv[])
#else
tpsvrinit(argc, argv)
int argc;
char **argv;
#endif
{
	/* Some compilers warn if argc and argv aren't used. */

	/* userlog writes to the central TUXEDO message log */
	userlog("Welcome to the simple server");
	return(0);
}

void process(struct container1 *data, int len)
{
	char tmp[80];
	char tc;
	int i;

	userlog("len(%d)", len);
	userlog("CH(%c)", data->ach);
	userlog("INT(%ld)",  data->bint);
	userlog("STR(%.40s)", data->cstr);
	userlog("LO(%ld)", data->dlo32);
	for(i = 0; i < sizeof(data->eca); i ++)
		sprintf(tmp + 2 * i, "%02x", (unsigned char)data->eca[i]);
	userlog("CA(%.40s)", tmp);

/*
	FILE *pf;
	pf = fopen("ffi", "w");
	fwrite(data->ffi, sizeof(data->ffi) - 1, 1, pf);
	fclose(pf);
*/

	memset(data->eca, data->ach, sizeof(data->eca));
	tc = data->ach + ('A' - '1');
	data->ach = tc;
	data->dlo32 += 1;
	memset(data->cstr, tc, sizeof(data->cstr) - 1);
	data->cstr[sizeof(data->cstr) - 1] = 0;

	if(data->ffi[0]) {
		memcpy(data->ffi, "0123456789", 10);
		memcpy(data->ffi + sizeof(data->ffi) - 10 - 1, "0123456789", 10);
		data->ffi[sizeof(data->ffi) - 1] = 0;
	}
}

void processlen(struct container1 *data, int len, int idx)
{
	char tmp[80];
	char tc;
	int i;
	int calen = 0;
	int strlen = 0;

	userlog("len(%d)", len);
	userlog("CH(%c)", data->ach);
	userlog("INT(%ld)",  data->bint);
	userlog("STR(%.40s)", data->cstr);
	userlog("LO(%ld)", data->dlo32);
	for(i = 0; i < sizeof(data->eca); i ++)
		sprintf(tmp + 2 * i, "%02x", (unsigned char)data->eca[i]);
	userlog("CA(%.40s)", tmp);

    tc = data->ach + idx;
	userlog("tc(%c)", tc);
	data->dlo32 += 1;
	memset(data->cstr, tc, sizeof(data->cstr) - 1);
	data->cstr[sizeof(data->cstr) - 1] = 0;
	calen = ((len-72) > sizeof(data->eca))? sizeof(data->eca) : (len-72);
	userlog( "calen(%d)", calen);
	memset(data->eca, tc, calen);
	if (calen == sizeof(data->eca) )
			strlen =  len - 92;
	memset(data->ffi, tc+1, strlen);

}

#ifdef __cplusplus
extern "C"
#endif
void
#if defined(__STDC__) || defined(__cplusplus)
CHANCONS(TPSVCINFO *rqst)
#else
CHANCONS(rqst)
TPSVCINFO *rqst;
#endif
{
	FBFR32 *req;
	FLDLEN32 len;
	int rc;
	int i, oc;
	char transid[LEN_TRANSID + 1];
	char program[LEN_PROGRAM + 1];
	char channame[LEN_CHANNAME + 1];
	char contname[LEN_CONTNAME + 1];
	char *p;
	struct container1 contdata1;
	struct container2 contdata2;
	struct container3 contdata3;
	FBFR32 *metainfo;

	int t1, t2;

	t1 = get_usec();

	req = (FBFR32 *)rqst->data;

    /* Allocate the metainfo space */
    metainfo = (FBFR32 *)tpalloc("FML32", NULL, 1024);
    if (metainfo == NULL) {
        userlog("Memory allocation failed");
        tpreturn(TPFAIL, 0, NULL, 0, 0);
    }
    if (tpgetcallinfo(req, &metainfo, 0) == 0 ) {
        char transid[LEN_TRANSID + 1];
        if (Fget32(metainfo, CX_TRANSID, 0, transid, &len) != -1) {
            transid[len] = 0;
            userlog("TRANSID: %s(%d)", transid, len);
        }
    }
    tpfree((char *)metainfo);

	if(0 == strcmp(rqst->name, "CHAN1")) {
		len = sizeof(transid);
		rc = Fget32(req, CX_TRANSID, 0, transid, &len);
		if(-1 == rc) {
			userlog("get transid failed %s", Fstrerror32(Ferror32));
			tpreturn(TPFAIL, 0, NULL, 0L, 0);
		}
		transid[len] = 0;

		len = sizeof(program);
		rc = Fget32(req, CX_PROGRAM, 0, program, &len);
		if(-1 == rc) {
			userlog("get program failed %s", Fstrerror32(Ferror32));
			tpreturn(TPFAIL, 0, NULL, 0L, 0);
		}
		program[len] = 0;

	    userlog("%s:%s(%d)", transid, program, len);
	}

	len = sizeof(channame);
	rc = Fget32(req, CX_CHANNEL_NAME, 0, channame, &len);
	if(-1 == rc) {
		userlog("get channelName failed %s", Fstrerror32(Ferror32));
		tpreturn(TPFAIL, 0, NULL, 0L, 0);
	}
	channame[len] = 0;
	
	oc = Foccur32(req, CX_CONTAINER_NAME);
	if(-1 == oc) {
		userlog("occur containerName failed %s", Fstrerror32(Ferror32));
		tpreturn(TPFAIL, 0, NULL, 0L, 0);
	}
	userlog("%s(%d)", channame, oc);

	for(i = 0; i < oc; i ++) {
		len = sizeof(contname);
		rc = Fget32(req, CX_CONTAINER_NAME, i, contname, &len);
		if(-1 == rc) {
			userlog("get containerName failed %s", Fstrerror32(Ferror32));
			tpreturn(TPFAIL, 0, NULL, 0L, 0);
		}
		contname[len] = 0;
	    userlog("%s", contname);

		if(0 == strcasecmp(contname, "container1"))
			p = (char *)&contdata1;
		else if(0 == strcasecmp(contname, "container2"))
			p = (char *)&contdata2;
		else if(0 == strcasecmp(contname, "container3"))
			p = (char *)&contdata3;
		else {
			userlog("unknown container");
			tpreturn(TPFAIL, 0, NULL, 0L, 0);
		}

/* Handle 3 containers in same way */
		len = sizeof(struct container1);
		rc = Fget32(req, CX_CONTAINER_DATA, i, p, &len);
		if(-1 == rc) {
			userlog("get containerData failed %s", Fstrerror32(Ferror32));
			tpreturn(TPFAIL, 0, NULL, 0L, 0);
		}
		if ( len < 400 &&  oc > 1)
			processlen((struct container1 *)p, len, i);
		else
			process( (struct container1 *)p, len );

		rc = Fchg32(req, CX_CONTAINER_DATA, i, p, len);
		if(-1 == rc) {
			userlog("chg containerData failed %s", Fstrerror32(Ferror32));
			tpreturn(TPFAIL, 0, NULL, 0L, 0);
		}
	}

	t2 = get_usec();
	userlog("elapsed: %d\t%d\t%d", t1, t2, t1 < t2 ? t2 - t1 : 1000000 + t2 - t1);

	tpreturn(TPSUCCESS, 0, (char *)req, 0L, 0);
}

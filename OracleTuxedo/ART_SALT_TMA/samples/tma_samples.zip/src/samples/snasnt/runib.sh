#!/bin/sh
# set -x

xi()
{
	X3270OUTPUT=6 X3270INPUT=5 x3270if 5>$ip 6<$op -v "$@"
}

# Failure.
die()
{
	xi "Info(\"Error: $@\")"
	xi "CloseScript(1)"
	exit 1
}

prep_3270()
{
# Start x3270
	s3270 -model 2 <$ip >$op &
	xp=$!

# hold the pipe open
	exec 5>$ip
	xi -s 0 >/dev/null || exit 1
}

logon_cics()
{
	xi "connect(\"$host:$port\")"
	xi "wait(output)"
	xi "string(\"$rlu\")"
	xi "enter"
#	xi "wait(1, seconds)"
	sleep 2
	xi "clear"
}

disconn()
{
	xi "disconnect()"
}

run_source()
{
	name=`echo $1 | sed 's/bmk\/\(.*\).ib/\1/'`
	echo "Run $name ..."
	rm -f $name.out

	. $1 >> s3270.log 2>&1
	if [ $? -ne 0 ]
	then
		echo "$name failed"
		return 1
	fi

	cat $name.out | diff bmk/${name}.bmk -
	if [ $? -ne 0 ]
	then
		echo "$name failed"
		return 1
	fi

	echo "$name passed"
	return 0
}


### main

host=wasa
port=23
lsys=$LSYSID
llu=$LOCALLU
rlu=$RLUNAME

ip=./ip.$$
op=./op.$$

rm -f $ip $op
trap "rm -f $ip $op" EXIT
trap "exit" INT QUIT HUP TERM
mknod $ip p
mknod $op p

prep_3270 > s3270.log 2>&1
logon_cics >> s3270.log 2>&1

allpass=true
if [ $# -lt 1 ]
then
	for i in `echo bmk/*.ib`
	do
		run_source $i || allpass=false
	done
else
	while [ $# -gt 0 ]
	do
		run_source bmk/$1.ib || allpass=false
		shift
	done
fi

disconn >> s3270.log 2>&1 

test $allpass = true || exit 1

exit 0

#!/bin/ksh
# set -x

myexit()
{ 
	echo "ERROR: $1 failed"
	ipclean
	exit 1
}

setCase()
{
	echo "\n# Set $Name on $Dir"

	cd $Dir
		tailor.sh > test.out 2>&1 <<!
			`head -8 $Top/sna.in`
			$TUXDIR
!
	if [ $? -ne 0 ]
	then
		myexit tailor.sh
	fi

	. ./setenv
	if [ -f setup.sh ]
	then
		setup.sh >> test.out 2>&1 || myexit setup.sh
	else
		gmake >> test.out 2>&1 || myexit make
	fi
}

runCase()
{
	echo "\n# Process $Name on $Dir"

	if [ "x$APPDIR" = "x" ]
	then
		. ./setenv
	fi

	tmboot -y >> test.out 2>&1 || myexit tmboot
	sleep 5
	
	if [ -f runob.sh ]
	then
		runob.sh  || myexit runob.sh
	fi
	
	if [ -f runib.sh ]
	then
		runib.sh  || myexit runib.sh
	fi
	
	tmshutdown -cy >> test.out 2>&1 || myexit tmshutdown
	ipclean >> test.out 2>&1
}

# Main

if [ $# -lt 1 ]
then
	echo "Usage: $0 case_id"
	exit 1	
fi
Name=$1

Top=$PWD
Dir=$Name
export PATH=$Top:$PATH

setCase
runCase

exit 0

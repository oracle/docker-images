#!/bin/sh

runqc()
{
	qcclnt -t HDPL4 -n 1 -d 0 -s 0
#	sleep 1
	qcclnt -t HDPL4 -n 1 -d 0 -s 0 -i 32000 -o 32000
#	sleep 1
	qcclnt -t HDPL4 -n 1 -d 0 -s 2
#	sleep 1
	qcclnt -t HDPL4 -n 1 -d 0 -s 2 -i 32000 -o 32000
#	sleep 1
	qcclnt -t HDPL4 -n 1 -d 0 -s 2 -l 1
#	sleep 1
	qcclnt -t HDTP4 -n 5 -d 0 -s 0
#	sleep 1
	qcclnt -t TDTP4 -n 5 -d 0 -s 0 -i 100 -o 32690 
#	sleep 1
	qcclnt -t TDTP4 -n 5 -d 0 -s 0 -i 32690 -o 100 
#	sleep 1
	qcclnt -t TDTP4 -n 5 -d 0 -s 2
#	sleep 1
	qcclnt -t HDTP4 -n 5 -d 0 -s 2
#	sleep 1
	qcclnt -t HDTP4 -n 6 -d 0 -s 0 -i 100 -o 32690
#	sleep 1
	qcclnt -t HDTP4 -n 6 -d 0 -s 2 -i 100 -o 32690
#	sleep 1
	qcclnt -t IDTP4 -n 1 -d 0 -s 0 -S $LSYSID 
#	sleep 1
	qcclnt -t IDTP4 -n 1 -d 0 -s 2 -S $LSYSID 
#	sleep 1
	qcclnt -t IDTP4 -n 5 -d 0 -s 0 -S $LSYSID 
#	sleep 1
	qcclnt -t IDTP4 -n 5 -d 0 -s 2 -S $LSYSID
}

## main ##

name="QC"

runqc > $name.out 2>&1
if [ $? -ne 0 ]
then
	echo "$name failed"
	exit 1
fi

# strings $name.out | diff $name.bmk -
# if [ $? -ne 0 ]
# then
# 	echo "$name failed"
# 	exit 1
# fi

# workaround
if [ `strings QC.out | grep good | wc -l` -ne 16 ]
then
	echo "$name failed"
	exit 1
fi

echo "$name passed"
exit 0

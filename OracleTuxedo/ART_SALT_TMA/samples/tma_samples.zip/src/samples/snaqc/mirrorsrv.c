/******************************************************************************
* mirrorsrv.c
*
* Copyright �1997-2000, BEA Systems, Inc., all rights reserved.
*/


/* Identification */

#if defined(__STDC__) || defined(__cplusplus)
static const char	mirrorsrv_c_id[] =
    "@(#)$Header: /repos/tma/sample/snaqc/mirrorsrv.c,v 1.1 2014/10/14 09:10:13 xixisun Exp $";
#endif

/* System includes */

#include <stdio.h>
#include <string.h>

#include <atmi.h>	/* TUXEDO Header File */
#include <userlog.h>	/* TUXEDO Header File */


/* tpsvrinit is executed when a server is booted, before it begins
   processing requests.  It is not necessary to have this function.
   Also available is tpsvrdone (not used in this example), which is
   called at server shutdown time.
*/

#if defined(__STDC__) || defined(__cplusplus)
int tpsvrinit(int argc, char *argv[])
#else
int tpsvrinit(argc, argv)
int argc;
char **argv;
#endif
{
	/* Some compilers warn if argc and argv aren't used. */
	argc = argc;
	argv = argv;

	/* userlog writes to the central TUXEDO message log */
	userlog("Welcome to the simple mirror server");
	return(0);
}


/* This function performs the actual service requested by the client.
   Its argument is a structure containing among other things a pointer
   to the data buffer, and the length of the data buffer.
*/

#ifdef __cplusplus
extern "C"
#endif
#if defined(__STDC__) || defined(__cplusplus)
void MIRROR(TPSVCINFO *forwardd)
#else
void MIRROR(forwardd)
TPSVCINFO *forwardd;
#endif
{

 char *forward, *backward;

 forward = forwardd->data;   /* point to the character string */
 backward = forward + forwardd->len - 2; /* point to last character */

 while (backward > forward) {
   *forward   ^= *backward;    /* switch the position of the characters */
   *backward  ^= *forward;
   *forward++ ^= *backward--;
 }

 tpreturn (TPSUCCESS, 0, forwardd->data, forwardd->len, 0);

}


#ifdef __cplusplus
extern "C"
#endif
#if defined(__STDC__) || defined(__cplusplus)
void DOUBLEMIRROR(TPSVCINFO *forwardd)
#else
void DOUBLEMIRROR(forwardd)
TPSVCINFO *forwardd;
#endif
{

 char *forward, *backward;
 char *doublestring;
 char *dummymsg = "HELLO FROM DOUBLEMIRROR";
 long doublelen, forwardlen;

 if ( (forwardlen = forwardd->len) == 0) {
	forwardlen = strlen(dummymsg) + 1; /* use the dummy message */
 	doublelen = (forwardlen * 2) + 3 - 1; /* prepare for return string */
	/* allocate a buffer to hold the string */
 	if ( (doublestring = tpalloc("STRING", NULL, doublelen) ) == NULL)
		tpreturn (TPFAIL, 0, NULL, 0, 0);
	strcpy(doublestring, dummymsg);
 }
 else {
 	doublelen = (forwardlen * 2) + 3 - 1; /* prepare for return string */
 	/* realloc the buffer to contain the new larger string */
 	if ( (doublestring = tprealloc(forwardd->data, doublelen) ) == NULL)
		tpreturn (TPFAIL, 0, NULL, 0, 0);
 }

 strcat(doublestring, " : ");  /* add the divider between the two strings */
 forward = doublestring + strlen(doublestring);
 strncat(doublestring, doublestring, (forwardlen - 1));
 backward = forward + strlen(forward) - 1;

 while (backward > forward) {
   *forward   ^= *backward;    /* switch the position of the characters */
   *backward  ^= *forward;
   *forward++ ^= *backward--;
 }

 tpreturn (TPSUCCESS, 0, doublestring, strlen(doublestring) + 1, 0);

}

/* End mirrorsrv.c */

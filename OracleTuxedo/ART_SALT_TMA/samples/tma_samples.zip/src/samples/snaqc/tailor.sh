#!/bin/ksh

check_tux()
{
	if [ `uname -s` != "Windows_NT" ]
	then
		ID=`whoami`
	else
		ID=`id -nu`
	fi
	
	EXISTING_IPCS=`ipcs | grep $ID | wc -l`
	if [ $EXISTING_IPCS -gt 0 ];
	then
		echo "\nWARNING: TUXEDO applications active for $ID.\n"
		ipcs | grep $ID
#		exit 1
	fi
}

read_para()
{
	read MAINFRAME?"Enter MAINFRAME: "
	read PORTNUM?"Enter PORTNUM: "
	read STACKTYPE?"Enter STACKTYPE: "
	read LOCALLU?"Enter LOCALLU: "
	read RLUNAME?"Enter RLUNAME: "
	read LSYSID?"Enter LSYSID: "
	read RSYSID?"Enter RSYSID: "
	read SNAGRP?"Enter SNAGRP: "
	read TUXDIR?"Enter TUXDIR: "

	HOST=`uname -n`
	IPCKEY=0
	while [ $IPCKEY -lt 32767 ]
	do
		IPCKEY=$RANDOM
		IPCKEY=`expr $IPCKEY + 32767`
	done
}

sed_temp()
{
    sed -e "s%##APPDIR##%$PWD%g" \
        -e "s%##IPCKEY##%$IPCKEY%g" \
        -e "s%##LOCALLU##%$LOCALLU%g" \
        -e "s%##LSYSID##%$LSYSID%g" \
        -e "s%##MACHINE##%$HOST%g" \
        -e "s%##MAINFRAME##%$MAINFRAME%g" \
        -e "s%##PORTNUM##%$PORTNUM%g" \
        -e "s%##RLUNAME##%$RLUNAME%g" \
        -e "s%##RSYSID##%$RSYSID%g" \
        -e "s%##SNAGRP##%$SNAGRP%g" \
        -e "s%##STACKTYPE##%$STACKTYPE%g" \
        -e "s%##TUXDIR##%$TUXDIR%g" \
		$1.template > $1
}


## main ##

check_tux
read_para

TPLTs=" \
	setenv \
	ubbconf \
	dmconf \
"

for i in $TPLTs
do
	echo $i
	sed_temp $i
done

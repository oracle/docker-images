
struct zv16x1 {
	char	tst_string[5];		/* null="\0" */
	char	tst_char;		/* null='\0' */
	char	tst_carray[3];		/* null="\0" */
	char	tst_zoned[7];		/* null="\0" */
	short	tst_short;		/* null=0 */
	char	tst_filr1[2];		/* null="\0" */
	long	tst_long;		/* null=0 */
	float	tst_float;		/* null=0.000000 */
	double	tst_double;		/* null=0.000000 */
	char	tst_packed[5];		/* null="\0" */
	char	tst_filler[19];		/* null="\0" */
};


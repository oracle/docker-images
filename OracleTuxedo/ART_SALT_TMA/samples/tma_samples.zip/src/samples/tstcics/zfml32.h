/*	fname	fldid            */
/*	-----	-----            */
#define	TST_STRING	((FLDID32)167780161)	/* number: 8001	 type: string */
#define	TST_CHAR	((FLDID32)67116866)	/* number: 8002	 type: char */
#define	TST_CARRAY	((FLDID32)201334595)	/* number: 8003	 type: carray */
#define	TST_ZONED	((FLDID32)167780164)	/* number: 8004	 type: string */
#define	TST_SHORT	((FLDID32)8005)	/* number: 8005	 type: short */
#define	TST_FILR1	((FLDID32)167780166)	/* number: 8006	 type: string */
#define	TST_LONG	((FLDID32)33562439)	/* number: 8007	 type: long */
#define	TST_FLOAT	((FLDID32)100671304)	/* number: 8008	 type: float */
#define	TST_DOUBLE	((FLDID32)134225737)	/* number: 8009	 type: double */
#define	TST_PACKED	((FLDID32)201334602)	/* number: 8010	 type: carray */
#define	TST_FILLER	((FLDID32)167780171)	/* number: 8011	 type: string */

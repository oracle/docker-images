/* @(#)TCP Arctic-2 test zviewc.c 1.1 98/04/07 15:06:29 */

/*
 * $RCSfile: zviewc.c,v $
 * $Revision: 1.4 $
 * $Date: 2010/07/09 03:32:37 $
 *
 * $Log: zviewc.c,v $
 * Revision 1.4  2010/07/09 03:32:37  xisun
 * Merge TUX100 to HEAD for 11g
 *
 * Revision 1.2  1999/05/18 16:02:41  killen
 * CR#A00100# modified FML pack and unpack to not use VIEWs
 *
 *
 */

/*=====================================================================*/
/* Client ztv16c1 Requests Service(IBMV161) From Server ZTVSRV1 On IBM */
/*=====================================================================*/

/*=====================================================================*/
/* note: this program assumes that zv161 and zv321 structures are      */
/* identical, and that zv16x2 and zv32x2 structures are identical.     */
/*=====================================================================*/


#include <stdio.h>			/* UNIX */
#include <string.h>			/* UNIX */
#include <decimal.h>		/* TUXEDO */
#include <atmi.h>			/* TUXEDO */
#include <userlog.h>			/* TUXEDO */
#include <fml32.h>			/* TUXEDO */
#include <fml.h>			/* TUXEDO */
#include <Usysflds.h>		/* TUXEDO */

#include "zfml16.h"
#include "zv161.h"			/* VIEW16 */
#include "zv16x2.h"			/* VIEW16 */

TPINIT *initbuf(char *app_pw, char *user, char *pwd);

struct info
{
	char t_string[80];
	char t_char;
	char t_carray[80];
	char t_zoned[80];
	short t_short;
	long t_long;
	float t_float;
	double t_double;
	char t_packed[80];
};

char *program;

/*------------------------------------------------------------------------*/

char *pop_1(newval, bit32)
struct info *newval;
int bit32;
{
	struct zv161 *v1dat;
	char *vtype;
	char *vname;

	vtype = bit32 ? "VIEW32" : "VIEW";
	vname = bit32 ? "zv321" : "zv161";

	/* we assume that zv161 and zv321 C structures are identical */

	v1dat = (struct zv161 *) tpalloc(vtype, vname, sizeof(struct zv161));

	if (NULL == (char *)v1dat) {
		fprintf(stderr, "%s: tpalloc failed, %s\n", program, tpstrerror(tperrno));
		exit(1);
  	}

	strcpy (v1dat->tst_string, newval->t_string);
	strcpy (v1dat->tst_carray, newval->t_carray);
	strcpy (v1dat->tst_zoned,  newval->t_zoned);
	v1dat->tst_char          = newval->t_char;
	v1dat->tst_short         = newval->t_short;
	v1dat->tst_long          = newval->t_long;
	v1dat->tst_float         = newval->t_float;
	v1dat->tst_double        = newval->t_double;
	deccvasc(newval->t_packed,5,&v1dat->tst_packed);

	return( (char *) v1dat );
}

/*------------------------------------------------------------------------*/

char *pop_x(newval, bit32)
struct info *newval;
int bit32;
{
	struct zv16x2 *v1dat;
	char *vtype;
	char *vname;

	vtype = bit32 ? "VIEW32" : "VIEW";
	vname = bit32 ? "zv32x2" : "zv16x2";

	/* we assume that zv16x2 and zv32x2 C structures are identical */

	v1dat = (struct zv16x2 *) tpalloc(vtype, vname, sizeof(struct zv16x2));

	if (NULL == (char *)v1dat) {
		fprintf(stderr, "%s: tpalloc failed, %s \n", program, tpstrerror(tperrno));
		exit(1);
  	}

	strcpy (v1dat->tst_string, newval->t_string);
	strcpy (v1dat->tst_carray, newval->t_carray);
	strcpy (v1dat->tst_zoned,  newval->t_zoned);
	strcpy (v1dat->tst_packed, newval->t_packed);
	v1dat->tst_char          = newval->t_char;
	v1dat->tst_short         = newval->t_short;
	v1dat->tst_long          = newval->t_long;
	v1dat->tst_float         = newval->t_float;
	v1dat->tst_double        = newval->t_double;

	return( (char *) v1dat );
}

/*------------------------------------------------------------------------*/

char *pop_f(newval, bit32)
struct info *newval;
int bit32;
{
	FBFR *fbuff;
	char *v1dat;
	char *ftype;
	int result;

	/* we assume that zv16x2 and zv32x2 C structures are identical */

	fbuff = (FBFR *) tpalloc("FML", NULL, Fneeded(22, sizeof(struct zv16x2) * 2));
 
	if(fbuff == NULL)
	{
		fprintf(stderr, "%s: FML alloc failed: %s\n", program, tpstrerror(tperrno));
		exit(1);
	}

	Fadd(fbuff, TST_STRING, newval->t_string, 5);
	Fadd(fbuff, TST_CHAR,   &(newval->t_char), sizeof(char));
	Fadd(fbuff, TST_CARRAY, newval->t_carray, 3);
	Fadd(fbuff, TST_ZONED,  newval->t_zoned, 6);
	Fadd(fbuff, TST_SHORT,  (char *) &(newval->t_short),  sizeof(short));
	Fadd(fbuff, TST_FILR1,  "YY",  2);
	Fadd(fbuff, TST_LONG,   (char *) &(newval->t_long),   sizeof(long));
	Fadd(fbuff, TST_FLOAT,  (char *) &(newval->t_float),  sizeof(float));
	Fadd(fbuff, TST_DOUBLE, (char *) &(newval->t_double), sizeof(double));
	Fadd(fbuff, TST_PACKED, newval->t_packed,  5);
	Fadd(fbuff, TST_FILLER, "XXXXXXXXXXXXXXXXXXXXX",  21);

	if(bit32)
	{
		FBFR32 *f2buff;
		int x;

		f2buff = (FBFR32 *) tpalloc("FML32", NULL, Fneeded32(22, sizeof(struct zv16x2) * 2));

		x = F16to32(f2buff, fbuff);

		if(x == -1)
		{
			printf("FML 16 to 32 conversion failed");
			return(NULL);
		}

		tpfree((char *) fbuff);
		return (char *) f2buff;
	}

	return (char *) fbuff;
} 

/*------------------------------------------------------------------------*/

char *populate(vtype, bit32, newval)
char vtype;
int bit32;
struct info *newval;
{
	char *v1dat;
	char cktype[20];
	char ckview[20];

	switch(vtype)
	{
	case '1':
		v1dat = pop_1(newval, bit32);
		break;

	case 'F':
		v1dat = pop_f(newval, bit32);
		break;

	case 'X':
		v1dat = pop_x(newval, bit32);
		break;

	default:
		fprintf(stderr, "%s: unsupported view type %c\n", program, vtype);
		exit(1);
	}

	tptypes(v1dat, cktype, ckview);
	printf("Sending %s %s\n", cktype, ckview);

	return v1dat;
}

/*------------------------------------------------------------------------*/

void unp_1(buffer, newval)
char *buffer;
struct info *newval;
{
	struct zv161 *v1dat;

	/* we assume that zv16x2 and zv32x2 C structures are identical */

	v1dat = (struct zv161 *) buffer;

	strcpy(newval->t_string, v1dat->tst_string);
	strcpy(newval->t_carray, v1dat->tst_carray);
	strcpy(newval->t_zoned, v1dat->tst_zoned);
	newval->t_char   = v1dat->tst_char;
	newval->t_short  = v1dat->tst_short;
	newval->t_long   = v1dat->tst_long;
	newval->t_float  = v1dat->tst_float;
	newval->t_double = v1dat->tst_double;
	dectoasc(&v1dat->tst_packed,newval->t_packed,6,2);
	newval->t_packed[6] = '\0';
}

/*------------------------------------------------------------------------*/

void unp_x(buffer, newval)
char *buffer;
struct info *newval;
{
	struct zv16x2 *v1dat;

	/* we assume that zv16x2 and zv32x2 C structures are identical */

	v1dat = (struct zv16x2 *) buffer;

	strcpy(newval->t_string, v1dat->tst_string);
	strcpy(newval->t_carray, v1dat->tst_carray);
	strcpy(newval->t_zoned,  v1dat->tst_zoned);
	strcpy(newval->t_packed, v1dat->tst_packed);
	newval->t_char   = v1dat->tst_char;
	newval->t_short  = v1dat->tst_short;
	newval->t_long   = v1dat->tst_long;
	newval->t_float  = v1dat->tst_float;
	newval->t_double = v1dat->tst_double;
}

/*------------------------------------------------------------------------*/

void unp_f(buffer, newval)
char *buffer;
struct info *newval;
{
	FBFR *fbuff;
	unsigned short x, len;
	char xtype[20];
	char xsubtype[20];

	tptypes(buffer, xtype, xsubtype);

	if(!strcmp(xtype, "FML32"))
	{
		fbuff = (FBFR *) tpalloc("FML", NULL, Fneeded(22, sizeof(struct zv16x2) * 2));

		x = F32to16(fbuff, (FBFR32 *) buffer);

		if(x == -1) printf("FML 32 to 16 conversion failed");
	}
	else
	{
		fbuff = (FBFR *) buffer;
	}

	len = 5;
	x = Fget(fbuff, TST_STRING, 0, newval->t_string, &len);
	len = 3;
	x = Fget(fbuff, TST_CARRAY, 0, newval->t_carray, &len);
	len = 7;
	x = Fget(fbuff, TST_ZONED, 0, newval->t_zoned, &len);
	len = 80;
	x = Fget(fbuff, TST_PACKED, 0, newval->t_packed, &len);
	len = sizeof(char);
	x = Fget(fbuff, TST_CHAR, 0, &(newval->t_char), &len);
	len = sizeof(short);
	x = Fget(fbuff, TST_SHORT, 0, (char *) &(newval->t_short), &len);
	len = sizeof(long);
	x = Fget(fbuff, TST_LONG, 0, (char *) &(newval->t_long), &len);
	len = sizeof(float);
	x = Fget(fbuff, TST_FLOAT, 0, (char *) &(newval->t_float), &len);
	len = sizeof(double);
	x = Fget(fbuff, TST_DOUBLE, 0, (char *) &(newval->t_double), &len);
}

/*------------------------------------------------------------------------*/

struct info *unpack(buffer)
char *buffer;
{
	struct info *newval;
	char cktype[20];
	char ckview[20];

	newval = (struct info *)malloc(sizeof(struct info));

	tptypes(buffer, cktype, ckview);
	printf("Received %s %s\n", cktype, ckview);

	     if(!strncmp(cktype, "FML", 3)) unp_f(buffer, newval);
	else if(!strcmp(ckview, "zv161"))   unp_1(buffer, newval);
	else if(!strcmp(ckview, "zv16x2"))  unp_x(buffer, newval);
	else if(!strcmp(ckview, "zv321"))   unp_1(buffer, newval);
	else if(!strcmp(ckview, "zv32x2"))  unp_x(buffer, newval);
	else
	{
		fprintf(stderr, "%s: unknown view type %s\n", program, ckview);
		exit(1);
	}

	return newval;
}

/*------------------------------------------------------------------------*/

disp(newval)
struct info *newval;
{
	printf("   T-STRING:     %.5s  \n",  newval->t_string);
	printf("   T-CHARACTER:  %c    \n",  newval->t_char);
	printf("   T-CARRAY:     %.3s  \n",  newval->t_carray);
	printf("   T-ZONED:      %.7s  \n",  newval->t_zoned);
	printf("   T-SHORT:      %d    \n",  newval->t_short);
	printf("   T-LONG:       %ld   \n",  newval->t_long);
	printf("   T-FLOAT       %f    \n",  newval->t_float);
	printf("   T-DOUBLE:     %f    \n",  newval->t_double);
	printf("   T-PACKED      %s    \n",  newval->t_packed);
}

/*------------------------------------------------------------------------*/

int compare(newval, oldval)
struct info *newval;
struct info *oldval;
{
	if(strcmp(newval->t_string,  oldval->t_string)) return(1);
	if(strcmp(newval->t_zoned,   oldval->t_zoned))  return(1);
	if(strncmp(newval->t_carray, oldval->t_carray, 3)) return(1);
	if(strncmp(newval->t_packed, oldval->t_packed, 5)) return(1);

	if(newval->t_char   != oldval->t_char)    return(1);
	if(newval->t_short  != oldval->t_short)   return(1);
	if(newval->t_long   != oldval->t_long)    return(1);

	/* allow rounding error for float and double */

	if( newval->t_float  - oldval->t_float  > 0.00001 )  return(1);
	if( newval->t_float  - oldval->t_float  < -0.00001 )  return(1);

	if( newval->t_double - oldval->t_double > 0.00001 )  return(1);
	if( newval->t_double - oldval->t_double < -0.00001 )  return(1);

	return(0);
}

/*------------------------------------------------------------------------*/

main(argc, argv)
int argc;
char **argv;
{
	char *v1dat;
	long reqlen;
	char service[20];
	struct info *newval;
	int bit32 = 0;

	struct info values;
        TPINIT *init;

	proc_name=argv[0];

	strcpy(values.t_string, "STR1");
	strcpy(values.t_carray, "123");
	strcpy(values.t_zoned,  "000886");
	strcpy(values.t_packed, "50.99");
	values.t_char   = 'A';
	values.t_short  = 1919;
	values.t_long   = 4321;
	values.t_float  = 28.28;
	values.t_double = 456.78;

	program = argv[0];

	if(argc != 3)
	{
		fprintf(stderr, "usage: %s 1/F/X 16/32\n", argv[0]);
		exit(1);
	}

	if(argc > 2)
		if(!strcmp(argv[2], "32"))
			bit32 = 1;

	/* Attach to System/T */

	init = initbuf("", "", "");

	if (tpinit(init) == -1) {
		fprintf(stderr, "%s: TPINIT failed: %s \n", program, tpstrerror(tperrno));
		exit(1);
  	}

	/* Allocate Send/Recv Buffers */

	v1dat = populate(argv[1][0], bit32, &values);

	disp(&values);

	/* Request Service */
	sprintf(service, "IBMV%s%s", argv[2], argv[1]);

	if (tpcall(service, (char *)v1dat, 0L, (char **)&v1dat, &reqlen,0L) == -1) {
		fprintf(stderr, "%s: TPCALL(%s) failed %s \n", program, service, tpstrerror(tperrno));
		exit(1);
	}

	newval=unpack(v1dat);

	disp(newval);

	if(compare(&values, newval))
	{
		userlog("*** FAIL: %s %s %s\n", argv[0], argv[1], argv[2]);
	}
	else
	{
		userlog("*** PASS: %s %s %s\n", argv[0], argv[1], argv[2]);
	}

	/* Free Buffers & Detach from System/T */
	tpfree((char *)v1dat);
	tpterm();
	exit(0);
}

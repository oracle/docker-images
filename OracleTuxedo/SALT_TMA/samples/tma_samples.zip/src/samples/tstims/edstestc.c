/*--------------------------------------------------------------------*/
/* (C) Copyright 1997  BEA Systems, Inc., All Rights Reserved.        */
/*                                                                    */
/* THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF                     */
/* BEA Systems, Inc.                                                  */
/* The copyright notice above does not evidence any                   */
/* actual of intended publication of such source code.                */
/*====================================================================*/
/*==== EDSTESTC         BEA CONNECT TCP FOR CICS                  *===*/
/*===*       - THIS PROGRAM IS A TEST MAINFRAME CLIENT THAT CALLS *===*/
/*===*         A SERVICE TOUPPER                                  *===*/
/*====================================================================*/

#include "beasysh"
#include "beacicsh"
#include "clienth"

/* MAX_DATALEN IS DEFINED IN BEACICSH */
/* BEA_REQUEST_RESPONSE IS DEFINED IN CLIENTH */

typedef struct CMAREA {
long DataLen;
char SvcName[16];
long RequestCd;
long ReturnCd;
long ReqReturnCd;
char reqdata[MAX_DATALEN];
} CMAREA ;

struct CMAREA carea;

void log_msg(char *recout, short Length)
{

 EXEC CICS WRITEQ TD  QUEUE  ('OTPL')
    FROM   (recout)
    LENGTH (Length);

 return;
}

void main(void)
{
 long resp, resp2;
 short lmsg;
 char errmsg[120];
 char recinto[4096];
 char taskNo[9];
 char returnData[100];
 int  returnLen;
 short int lrec;
 long ecaddr;
 int cd;

 EXEC CICS ADDRESS EIB(dfheiptr);

 /*lrec = 50;
 EXEC CICS RECEIVE INTO(recinto) LENGTH(&lrec);
 if (recinto[5] < '0' || recinto[5] > '9')
    recinto[5] = '1';*/
 memset(carea.reqdata, '\0', MAX_DATALEN);

 carea.ReturnCd = 0;
 carea.ReqReturnCd = 0;

 carea.RequestCd = BEA_REQUEST_RESPONSE;
 memset(carea.SvcName, ' ', 16);
 memcpy(carea.SvcName, "TOUPPER", 7);
 /*mcpy(&carea.CltHdr.SvcName[7], &recinto[5], 1);*/
 sprintf(taskNo, "%08D(7,0)",
                  *((decimal(7,0) *)dfheiptr->eibtaskn));
 sprintf(carea.reqdata, "This is a loop back test, task number(%s)",
                        taskNo);

 carea.DataLen = strlen(carea.reqdata);
 sprintf(returnData, "THIS IS A LOOP BACK TEST, TASK NUMBER(%s)",
                        taskNo);

 returnLen = strlen(carea.reqdata);
 lmsg = sizeof(CMAREA);

 EXEC CICS LINK PROGRAM("BEAPRERQ")
                COMMAREA(&carea)
                LENGTH(lmsg) RESP(resp) RESP2(resp2);

 if((DFHRESP(NORMAL) != resp) ||
    (carea.ReturnCd != 0) ||
    (carea.ReqReturnCd != 0))
 {
     sprintf(errmsg,
             "Return error Resp(%d) ReturnCd(%d) ReqReturnCd(%d)",
             resp, carea.ReturnCd, carea.ReqReturnCd);
     lmsg = strlen(errmsg);

     EXEC CICS SEND TEXT FROM(errmsg)
                         LENGTH(lmsg)
                         ERASE
                         FREEKB;
     log_msg(errmsg, lmsg);
     EXEC CICS RETURN;
 }
 /*if (carea.DataLen != returnLen)
 {
     sprintf(errmsg,
             "Error in return correct length(%d) return length(%d)",
             returnLen, carea.DataLen);
     lmsg = strlen(errmsg);

     EXEC CICS SEND TEXT FROM(errmsg)
                         LENGTH(lmsg)
                         ERASE
                         FREEKB;
     log_msg(errmsg, lmsg);
     EXEC CICS RETURN;
     } */
 if (memcmp(carea.reqdata, returnData, returnLen) != 0)
 {
     sprintf(errmsg,
             "Error in return data corr(%s) ret(%s)",
             returnData, carea.reqdata);
     lmsg = strlen(errmsg);

     EXEC CICS SEND TEXT FROM(errmsg)
                         LENGTH(lmsg)
                         ERASE
                         FREEKB;
     log_msg(errmsg, lmsg);
     EXEC CICS RETURN;
 }


 strcpy(errmsg, "Normal completion");
 lmsg = strlen(errmsg);
 EXEC CICS SEND TEXT FROM(errmsg)
                         LENGTH(lmsg)
                         ERASE
                         FREEKB;
 EXEC CICS RETURN;

}


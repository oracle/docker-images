#!/bin/ksh
# set -x

myexit()
{ 
	echo "ERROR: $1 failed"
	ipclean
	exit 1
}

setCase()
{
	echo "\n# Set $Name on $Dir"

	cd $Dir
		setup > test.out 2>&1 <<!
			`head -8 $Top/tcp.in`
			$TUXDIR
!
	if [ $? -ne 0 ]
	then
		myexit tailor.sh
	fi

	. ./setenv
}

runCase()
{
	echo "\n# Process $Name on $Dir"

	if [ "x$APPDIR" = "x" ]
	then
		. ./setenv
	fi

	tmboot -y >> test.out 2>&1 || myexit tmboot
	sleep 5
	
	./runvwc
	
	tmshutdown -cy >> test.out 2>&1 || myexit tmshutdown
	ipclean >> test.out 2>&1
}

# Main

if [ $# -lt 1 ]
then
	echo "Usage: $0 case_id"
	exit 1	
fi
Name=$1

Top=$PWD
Dir=$Name
export PATH=$Top:$PATH

setCase
runCase

exit 0

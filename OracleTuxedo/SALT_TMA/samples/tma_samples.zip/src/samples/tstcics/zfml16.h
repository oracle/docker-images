/*	fname	fldid            */
/*	-----	-----            */
#define	TST_STRING	((FLDID)48961)	/* number: 8001	 type: string */
#define	TST_CHAR	((FLDID)24386)	/* number: 8002	 type: char */
#define	TST_CARRAY	((FLDID)57155)	/* number: 8003	 type: carray */
#define	TST_ZONED	((FLDID)48964)	/* number: 8004	 type: string */
#define	TST_SHORT	((FLDID)8005)	/* number: 8005	 type: short */
#define	TST_FILR1	((FLDID)48966)	/* number: 8006	 type: string */
#define	TST_LONG	((FLDID)16199)	/* number: 8007	 type: long */
#define	TST_FLOAT	((FLDID)32584)	/* number: 8008	 type: float */
#define	TST_DOUBLE	((FLDID)40777)	/* number: 8009	 type: double */
#define	TST_PACKED	((FLDID)57162)	/* number: 8010	 type: carray */
#define	TST_FILLER	((FLDID)48971)	/* number: 8011	 type: string */

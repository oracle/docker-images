
To set up for testing on a UNIX platform:

1. Change the IPCKEY entry in ubbconfig.z if you are sharing the machine
     with other users.
 
2. Execute the setaddr script as:

   . ./setup <dir> <host>

   (where <dir> is the location of the TUXEDO directory, and <host> is
   the name of the remote system (such as dalvs2).  This will set
   up the environment, build the programs, set up environment and 
   security files, and do tmloadcf and dmloadcf)

   NOTE: it's important to do '. ./setup' and not just 'setup', as this
         script changes environment variables.

3. Boot the system as follows:

   tmboot -y

4. Run the test script as follows:

   runallI


To set up for testing on an NT platform:

1. Edit setup.cmd to contain the correct MSDEVSTD, and APPDIR
   directories.  (this script runs under DOS shell, so keep the slashes
   as \ ).

2. Change the IPCKEY entry in ubbconfig.z if you are sharing the machine
   with other users.

3. Execute the setenv.cmd script, then execute the setaddr script as:

   setup.cmd <dir> <host>

   (where <dir> is the location of the TUXEDO directory, and <host> is
   the name of the remote system (such as dalvs2).  This will set
   up the environment, build the programs, set up environment and 
   security files, and do tmloadcf and dmloadcf)

4. Boot the system as follows:

   tmboot -y

5. Run the test script as follows:

   runallI.cmd



struct zv161 {
	char	tst_string[5];
	char	tst_char;
	char	tst_carray[3];
	char	tst_zoned[7];
	short	tst_short;
	char	tst_filr1[2];
	long	tst_long;
	float	tst_float;
	double	tst_double;
	dec_t	tst_packed;
	char	tst_filler[21];
};


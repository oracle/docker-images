
#include <stdio.h>		/* UNIX */
#include "atmi.h"		/* TUXEDO */
#include "userlog.h"		/* TUXEDO */

TPINIT *initbuf(char *app_pw, char *user, char *pwd)
{
	char *result;
	TPINIT *init;
	char x_app_pw[20];
	char x_user[20];
	char x_pwd[20];

	strcpy(x_app_pw, app_pw);
	if(!x_app_pw[0])
		if(result = tuxgetenv("GWI_APP_PW"))
			strcpy(x_app_pw, result);

	strcpy(x_user, user);
	if(!x_user[0])
		if(result = tuxgetenv("GWI_USER"))
			strcpy(x_user, result);

	strcpy(x_pwd, pwd);
	if(!x_pwd[0])
		if(result = tuxgetenv("GWI_PWD"))
			strcpy(x_pwd, result);

        if(TPAPPAUTH == tpchkauth())
	{
		init = (TPINIT *) tpalloc("TPINIT", NULL, 2 * TPINITNEED(8) + 64);

		if(init == NULL) {
			fprintf(stderr, "TPALLOC error\n");
			exit(1);
		}

		strcpy(init->usrname, x_user);
		strcpy(init->passwd, x_app_pw);
		strcpy(init->cltname, "");

		init->grpname[0] = 0;
		init->flags = TPU_IGN;
		init->datalen = 8;
		strcpy(&(init->data), x_pwd);
	}
	else
	{
		init = NULL;
	}

	return(init);
}

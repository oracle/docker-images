rm -f ${APPDIR}/TLOG
tmadmin -c << EOF
crdl -z ${APPDIR}/TLOG -b 2000
quit
EOF

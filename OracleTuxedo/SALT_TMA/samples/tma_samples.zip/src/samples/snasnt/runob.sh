#!/bin/sh

run_source()
{
	name=`echo $1 | sed 's/bmk\/\(.*\).ob/\1/'`
	echo "Run $name ..."
	rm -f $name.out

	. $1 >> $name.out 2>&1
	if [ $? -ne 0 ]
	then
		echo "$name failed"
		return 1
	fi

	cat $name.out | diff bmk/${name}.bmk -
	if [ $? -ne 0 ]
	then
		echo "$name failed"
		return 1
	fi

	echo "$name passed"
	return 0
}


### main

allpass=true
if [ $# -lt 1 ]
then
	for i in `echo bmk/*.ob`
	do
		run_source $i || allpass=false
	done
else
	while [ $# -gt 0 ]
	do
		run_source bmk/$1.ob || allpass=false
		shift
	done
fi

/*	(c) 2003 BEA Systems, Inc. All Rights Reserved. */
/*	Copyright (c) 1997 BEA Systems, Inc.
  	All rights reserved

  	THIS IS UNPUBLISHED PROPRIETARY
  	SOURCE CODE OF BEA Systems, Inc.
  	The copyright notice above does not
  	evidence any actual or intended
  	publication of such source code.
*/

/* #ident	"@(#) samples/atmi/simpapp/simpserv.c	$Revision: 1.2 $" */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <atmi.h>	/* TUXEDO Header File */
#include <userlog.h>	/* TUXEDO Header File */

#include "bufview.h"
/* tpsvrinit is executed when a server is booted, before it begins
   processing requests.  It is not necessary to have this function.
   Also available is tpsvrdone (not used in this example), which is
   called at server shutdown time.
*/

#if defined(__STDC__) || defined(__cplusplus)
tpsvrinit(int argc, char *argv[])
#else
tpsvrinit(argc, argv)
int argc;
char **argv;
#endif
{
	/* Some compilers warn if argc and argv aren't used. */
	if(tpopen() == -1) {
		userlog("Resource manager open failed");
		return(-1);
	}

	/* userlog writes to the central TUXEDO message log */
	userlog("Welcome to the simple server");
	return(0);
}

/*
void reverse(char *str, int beg, int end)
{
	char c;
   
	if(beg >= end)
		return;   

	c = *(str + beg);
    *(str + beg) = *(str + end);
	*(str + end) = c;
	reverse(str, ++ beg, -- end);
}
*/

void disp(char *head, struct flat *pvw)
{
	char tmp[80];
	int i;

	userlog("%s:\n", head);
	userlog("CH(%c)\n", pvw->Ach);
	userlog("SH(%d)\n",  pvw->Bsh);
	userlog("STR(%.40s)\n", pvw->Cstr);
	userlog("LO(%ld)\n", pvw->Dlo);
	for(i = 0; i < sizeof(pvw->Eca); i ++)
		sprintf(tmp + 2 * i, "%02x", (unsigned char)pvw->Eca[i]);
	userlog("CA(%.40s)\n", tmp);
}

/* This function performs the actual service requested by the client.
   Its argument is a structure containing among other things a pointer
   to the data buffer, and the length of the data buffer.
*/

#ifdef __cplusplus
extern "C"
#endif
void
#if defined(__STDC__) || defined(__cplusplus)
KVA5(TPSVCINFO *msg)
#else
KVA5(msg)
TPSVCINFO *msg;
#endif
{
	char txt[40];
	int i;
	int cd;
	int rc;
	long len;
	long revent;
	struct flat *req;
	struct flat1 *resp;

	cd = msg->cd;
	req = (struct flat *)msg->data;

	sprintf(txt, "Recv(%d)", msg->len);
	disp(txt, (struct flat *)req);

	strcpy(txt, "flat1");
  	resp = (struct flat1 *)tpalloc("VIEW32", txt, sizeof(struct flat1));
	if(resp == NULL) {
		userlog("tpalloc %s failed (%s)\n", txt, tpstrerror(tperrno));
		tpreturn(TPFAIL, tperrno, NULL, 0L, 0);
  	}
	memset(resp, 0, sizeof(struct flat1));

	memcpy(resp, req, sizeof(struct flat));
	resp->Ach += ('a' - '1');
	resp->Bsh = sizeof(struct flat1);
	strcpy(resp->Cstr, msg->name);
	resp->Dlo ++;
	for(i = 0; i < sizeof(resp->Eca); i ++)
		resp->Eca[i] = i;
	memset(resp->Ffi, ' ', sizeof(resp->Ffi) - 1);
	memcpy(resp->Ffi, "1234567890", 10);
	memcpy(resp->Ffi + sizeof(resp->Ffi) - 11, "1234567890", 10);

	rc = tpsend(msg->cd, (char *)resp, 0, TPSIGRSTRT, &revent);
	if(rc == -1) {
		userlog("tpsend failed: %s\n", tpstrerror(tperrno));
		tpfree((char *)resp);
		tpreturn(TPFAIL, tperrno, (char *)0, 0L, 0);
	}

	sprintf(txt, "Send(%d)", resp->Bsh);
	disp(txt, (struct flat *)resp);

	tpfree((char *)resp);

	/* Return the transformed buffer to the requestor. */
	tpreturn(TPSUCCESS, 0, NULL, 0L, 0);
}

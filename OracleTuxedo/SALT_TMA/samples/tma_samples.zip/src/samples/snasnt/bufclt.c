/*=====================================================================*/
/* Client zviewcln Requests Service(VIEW$$) From Server ZVIEWSRV On IBM*/
/*=====================================================================*/
#include <stdio.h>          /* UNIX */
#include <string.h>         /* UNIX */
#include <time.h>          /* UNIX */
/*#include <decimal.h>*/      /* TUXEDO */
#include <atmi.h>           /* TUXEDO */
#include <userlog.h>        /* TUXEDO */
#ifdef _TMFML32
#include <fml32.h>          /* TUXEDO */
#include <fml1632.h>        /* TUXEDO */
#else
#include <fml.h>            /* TUXEDO */
#include <Usysflds.h>       /* TUXEDO */
#endif
#include "bufview.h"        /* VIEW32 */
#include "buffml.h"         /* FML32 */
/* we use a generic structure since all 
** the views used have the same layout */
/*---------------------------------------------------------------------*/
void disp(char *head, struct flat *pvw)
{
	int i;

	printf("%s:\n", head);
	printf("CH(%c)\n", pvw->Ach);
	printf("SH(%d)\n",  pvw->Bsh);
	printf("STR(%.40s)\n",  pvw->Cstr);
	printf("LO(%ld)\n",  pvw->Dlo);
	printf("CA(");
	for(i = 0; i < sizeof(pvw->Eca); i ++)
		printf("%02x", (unsigned char)pvw->Eca[i]);
	printf(")\n");
}

flatview(char *svc)
{
	char txt[32];
	struct flat *req;
	struct flat1 *resp;
	long len;

  	strcpy(txt, "flat");
  	req = (struct flat *)tpalloc("VIEW32", txt, sizeof(struct flat));
	if(req == NULL) {
        printf("tpalloc %s failed (%s)\n", txt, tpstrerror(tperrno));
		return(-1);
  	}
  	memset(req, 0, sizeof(struct flat));
    req->Ach = '1';
    req->Bsh = sizeof(struct flat);
    strcpy(req->Cstr, svc);
	if(sizeof(long) == 4 || getenv("LONG64_TO_S9_9_COMP"))
		req->Dlo = 999999999;
	else {
		strcat(req->Cstr, "1");
		req->Dlo = 999999999999999999;
	}
	memset(req->Eca, 1, sizeof(req->Eca));

	printf("%s:\n", svc);
	disp("Send", req);
	printf("\n");

  	strcpy(txt, "flat1");
  	resp = (struct flat1 *)tpalloc("VIEW32", txt, sizeof(struct flat1));
	if(resp == NULL) {
        printf("tpalloc %s failed (%s)\n", txt, tpstrerror(tperrno));
		return(-1);
  	}
  	memset(resp, 0, sizeof(struct flat1));

/*
  if(tpcall(servicenn, (char *)req, 0L, (char **)&req, &len, 0L) == -1) {
*/
  	if(tpcall(svc, (char *)req, 0L, (char **)&resp, &len, TPNOTIME) == -1) {
		printf("tpcall %s failed (%s)\n", svc, tpstrerror(tperrno)); 
		return(-1);
    }

	sprintf(txt, "Recv(%ld)", len);
  	disp(txt, (struct flat *)resp);
	printf("FI(%.10s ... %s)\n", resp->Ffi, resp->Ffi + sizeof(resp->Ffi) - 11);

  	tpfree((char *)req);
  	tpfree((char *)resp);
	return(0);
}

nestview(char *svc)
{
	char txt[32];
	struct nest *req;
	struct nest1 *resp;
	long len;
	int i, j;

  	strcpy(txt, "nest");
  	req = (struct nest *)tpalloc("VIEW32", txt, sizeof(struct nest));
	if(req == NULL) {
        printf("tpalloc %s failed (%s)\n", txt, tpstrerror(tperrno));
		return(-1);
  	}
  	memset(req, 0, sizeof(struct nest));

    req->Ach = '2';
    req->Bsh = sizeof(struct nest);
    strcpy(req->Cstr, svc);
	if(sizeof(long) == 4 || getenv("LONG64_TO_S9_9_COMP"))
		req->Dlo = 999999999;
	else {
		strcat(req->Cstr, "1");
		req->Dlo = 999999999999999999;
	}
	for(i = 0; i < 2; i ++){
		for(j = 0; j < sizeof(req->EVW_v[i].EAch); j ++)
			req->EVW_v[i].EAch[j] = '0' + i * 2 + j;
		req->EVW_v[i].EBsh = 0x1111 * i;
		for(j = 0; j < sizeof(req->EVW_v[i].ECVW_v.ECAch); j ++)
			req->EVW_v[i].ECVW_v.ECAch[j] = 'a' + i * 4 + j;
		for(j = 0; j < sizeof(req->EVW_v[i].EDVW_v.EDAch); j ++)
			req->EVW_v[i].EDVW_v.EDAch[j] = 'z' - i * 2 - j;
	}

	printf("%s: %s(%d)\n", svc, txt, sizeof(struct nest));
	disp("Send", (struct flat *)req);
	printf("\n");

  	strcpy(txt, "nest1");
  	resp = (struct nest1 *)tpalloc("VIEW32", txt, sizeof(struct nest1));
	if(resp == NULL) {
        printf("tpalloc %s failed (%s)\n", txt, tpstrerror(tperrno));
		return(-1);
  	}
  	memset(resp, 0, sizeof(struct nest1));

  	if(tpcall(svc, (char *)req, 0L, (char **)&resp, &len, TPNOTIME) == -1) {
		printf("tpcall %s failed (%s)\n", svc, tpstrerror(tperrno)); 
		return(-1);
    }

	sprintf(txt, "Recv(%ld)", len);
  	disp(txt, (struct flat *)resp);
	for(i = 0; i < 2; i ++){
		printf("EAch(%.2s)\n", resp->EVW_v[i].EAch);
		printf("EBsh(%d)\n", resp->EVW_v[i].EBsh);
		printf("ECAch(%.4s)\n", resp->EVW_v[i].ECVW_v.ECAch);
		printf("EDAch(%.2s)\n", resp->EVW_v[i].EDVW_v.EDAch);
	}
	printf("Ffi(%.10s ... %s)\n", resp->Ffi, resp->Ffi + sizeof(resp->Ffi) - 11);

  	tpfree((char *)req);
  	tpfree((char *)resp);
	return(0);
}

flatfml(char *svc)
{
  	char txt[32];
  	struct flat1 *pvw;
  	FBFR32 *pfml;
  	long len;

  	strcpy(txt, "flat1");
  	pvw = (struct flat1 *)tpalloc("VIEW32", txt, sizeof(struct flat1));
	if(pvw == NULL) {
        printf("tpalloc %s failed (%s)\n", txt, tpstrerror(tperrno));
		return(-1);
  	}
  	memset(pvw, 0, sizeof(struct flat1));

	pfml = (FBFR32 *)tpalloc("FML32", NULL, 32600); 
	if(pfml == NULL) {
		printf("tpcalloc FML32 failed (%s)\n", tpstrerror(tperrno));
		return(-1);
	}

	pvw->Ach = '3';
    Fchg32(pfml, ACH, 0, (char *)&(pvw->Ach), 0);
	pvw->Bsh = Fsizeof32(pfml);
	Fchg32(pfml, BSH, 0, (char *)&(pvw->Bsh), 0);
	strcpy(pvw->Cstr, svc);
	if(sizeof(long) == 4 || getenv("LONG64_TO_S9_9_COMP"))
		pvw->Dlo = 999999999;
	else {
		strcat(pvw->Cstr, "1");
		pvw->Dlo = 999999999999999999;
	}
    Fchg32(pfml, CSTR, 0, pvw->Cstr, 0);
	Fchg32(pfml, DLO, 0, (char *)&(pvw->Dlo), 0);
	memset(pvw->Eca, 3, sizeof(pvw->Eca));
    Fchg32(pfml, ECA, 0, pvw->Eca, sizeof(pvw->Eca));

	printf("%s Send:\n", svc);
	Fprint32(pfml);

	if(tpcall(svc, (char *)pfml, 0L, (char **)&pfml, &len, TPNOTIME) == -1) {
		printf("tpcall %s failed (%s)\n", svc, tpstrerror(tperrno)); 
		return(-1);
    }

	if(Fvftos32(pfml, (char *)pvw, txt) == -1) {
    	printf("Fvftos32 failed (%s)\n", tpstrerror(tperrno));
		return(-1);
  	} 
	sprintf(txt, "Recv(%ld)", len);
  	disp(txt, (struct flat *)pvw);
	printf("FI(%.10s ... %s)\n", pvw->Ffi, pvw->Ffi + sizeof(pvw->Ffi) - 11);

	tpfree((char *)pfml);
  	tpfree((char *)pvw);
	return(0);
}

nestfml(char *svc)
{
	char txt[32];
  	struct flat *pvw;
  	FBFR32 *pflt;
	FBFR32 *pf4f;
  	long len;
	char *p;
	FLDLEN32 l = 0;

  	strcpy(txt, "flat");
  	pvw = (struct flat *)tpalloc("VIEW32", txt, sizeof(struct flat));
	if(pvw == NULL) {
        printf("tpalloc %s failed (%s)\n", txt, tpstrerror(tperrno));
		return(-1);
  	}
  	memset(pvw, 0, sizeof(struct flat));

	pflt = (FBFR32 *)tpalloc("FML32", NULL, 256); 
	if(pflt == NULL) {
		printf("tpcalloc FML32 failed (%s)\n", tpstrerror(tperrno));
		return(-1);
	}

	pvw->Ach = '4';
    Fchg32(pflt, ACH, 0, (char *)&(pvw->Ach), 0);
	pvw->Bsh = Fsizeof32(pflt);
	Fchg32(pflt, BSH, 0, (char *)&(pvw->Bsh), 0);
	strcpy(pvw->Cstr, svc);
	if(sizeof(long) == 4 || getenv("LONG64_TO_S9_9_COMP"))
		pvw->Dlo = 999999999;
	else {
		strcat(pvw->Cstr, "1");
		pvw->Dlo = 999999999999999999;
	}
    Fchg32(pflt, CSTR, 0, pvw->Cstr, 0);
	Fchg32(pflt, DLO, 0, (char *)&(pvw->Dlo), 0);
	memset(pvw->Eca, 4, sizeof(pvw->Eca));
    Fchg32(pflt, ECA, 0, pvw->Eca, sizeof(pvw->Eca));

	pf4f = (FBFR32 *)tpalloc("FML32", NULL, 32600);
	if(pf4f == NULL) {
		printf("tpcalloc FML32 failed (%s)\n", tpstrerror(tperrno));
		return(-1);
	}

	Fadd32(pf4f, FLTF, (char *)pflt, 0);

	printf("%s Send:\n", svc);
	Fprint32(pf4f);

	if(tpcall(svc, (char *)pf4f, 0L, (char **)&pf4f, &len, TPNOTIME) == -1) {
		printf("tpcall %s failed (%s)\n", svc, tpstrerror(tperrno)); 
		return(-1);
    }

	Fget32(pf4f, FLTF, 0, (char *)pflt, 0);
	if(Fvftos32(pflt, (char *)pvw, txt) == -1) {
    	printf("Fvftos32 failed (%s)\n", tpstrerror(tperrno));
		return(-1);
  	} 
	sprintf(txt, "Recv(%ld)", len);
  	disp(txt, (struct flat *)pvw);
	p = Ffind32(pf4f, FFI, 0, &l);
	printf("FI(%d, %.10s ... %s)\n", l, p, p + l - 11);

  	tpfree((char *)pf4f);
	tpfree((char *)pflt);
  	tpfree((char *)pvw);
	return(0);
}

fmlview(char *svc)
{
  	char txt[32];
	struct nest *pvw;
  	FBFR32 *pfml;
	FVIEWFLD fvf;
  	long len;
	int i, j;
	char *p;
	FLDLEN32 l = 0;

  	strcpy(txt, "nest");
  	pvw = (struct nest *)tpalloc("VIEW32", txt, sizeof(struct nest));
	if(pvw == NULL) {
        printf("tpalloc %s failed (%s)\n", txt, tpstrerror(tperrno));
		return(-1);
  	}
  	memset(pvw, 0, sizeof(struct nest));

    pvw->Ach = '5';
    pvw->Bsh = sizeof(struct nest);
    strcpy(pvw->Cstr, svc);
	if(sizeof(long) == 4 || getenv("LONG64_TO_S9_9_COMP"))
		pvw->Dlo = 999999999;
	else {
		strcat(pvw->Cstr, "1");
		pvw->Dlo = 999999999999999999;
	}
	for(i = 0; i < 2; i ++){
		for(j = 0; j < sizeof(pvw->EVW_v[i].EAch); j ++)
			pvw->EVW_v[i].EAch[j] = '0' + i * 2 + j;
		pvw->EVW_v[i].EBsh = 0x1111 * i;
		for(j = 0; j < sizeof(pvw->EVW_v[i].ECVW_v.ECAch); j ++)
			pvw->EVW_v[i].ECVW_v.ECAch[j] = 'a' + i * 4 + j;
		for(j = 0; j < sizeof(pvw->EVW_v[i].EDVW_v.EDAch); j ++)
			pvw->EVW_v[i].EDVW_v.EDAch[j] = 'z' - i * 2 - j;
	}

	pfml = (FBFR32 *)tpalloc("FML32", NULL, 32600); 
	if(pfml == NULL) {
		printf("tpcalloc FML32 failed (%s)\n", tpstrerror(tperrno));
		return(-1);
	}

	strcpy(fvf.vname, "nest");
	fvf.data = (char *)pvw;
	Fadd32(pfml, NEST, (char *)&fvf, 0);

	printf("%s Send:\n", svc);
	Fprint32(pfml);

	if(tpcall(svc, (char *)pfml, 0L, (char **)&pfml, &len, TPNOTIME) == -1) {
		printf("tpcall %s failed (%s)\n", svc, tpstrerror(tperrno)); 
		return(-1);
    }

	Fget32(pfml, NEST, 0, (char *)&fvf, 0);
	pvw = (struct nest *)fvf.data;
	sprintf(txt, "Recv(%ld)", len);
  	disp(txt, (struct flat *)pvw);
	for(i = 0; i < 2; i ++){
		printf("EAch(%.2s)\n", pvw->EVW_v[i].EAch);
		printf("EBsh(%d)\n", pvw->EVW_v[i].EBsh);
		printf("ECAch(%.4s)\n", pvw->EVW_v[i].ECVW_v.ECAch);
		printf("EDAch(%.2s)\n", pvw->EVW_v[i].EDVW_v.EDAch);
	}
	p = Ffind32(pfml, FFI, 0, &l);
	printf("FI(%d, %.10s ... %s)\n", l, p, p + l - 11);

	tpfree((char *)pfml);
  	tpfree((char *)pvw);
	return(0);
}

ffmlvw(char *svc)
{
  	char txt[32];
	struct nest *pvw;
  	FBFR32 *pfml;
  	long len;
	int i, j;
	char fi[32001];

  	strcpy(txt, "nest");
  	pvw = (struct nest *)tpalloc("VIEW32", txt, sizeof(struct nest));
	if(pvw == NULL) {
        printf("tpalloc %s failed (%s)\n", txt, tpstrerror(tperrno));
		return(-1);
  	}
  	memset(pvw, 0, sizeof(struct nest));

	pfml = (FBFR32 *)tpalloc("FML32", NULL, 32600); 
	if(pfml == NULL) {
		printf("tpcalloc FML32 failed (%s)\n", tpstrerror(tperrno));
		return(-1);
	}

	pvw->Ach = '6';
    Fchg32(pfml, ACH, 0, (char *)&(pvw->Ach), 0);
	pvw->Bsh = Fsizeof32(pfml);
	Fchg32(pfml, BSH, 0, (char *)&(pvw->Bsh), 0);
	strcpy(pvw->Cstr, svc);
	if(sizeof(long) == 4 || getenv("LONG64_TO_S9_9_COMP"))
		pvw->Dlo = 999999999;
	else {
		strcat(pvw->Cstr, "1");
		pvw->Dlo = 999999999999999999;
	}
    Fchg32(pfml, CSTR, 0, pvw->Cstr, 0);
	Fchg32(pfml, DLO, 0, (char *)&(pvw->Dlo), 0);
	for(i = 0; i < 2; i ++){
		for(j = 0; j < sizeof(pvw->EVW_v[i].EAch); j ++) {
			pvw->EVW_v[i].EAch[j] = '0' + i * 2 + j;
			Fadd32(pfml, EACH, (char *)&(pvw->EVW_v[i].EAch[j]), 0);
		}
		pvw->EVW_v[i].EBsh = 0x1111 * i;
		Fadd32(pfml, EBSH, (char *)&(pvw->EVW_v[i].EBsh), 0);
		for(j = 0; j < sizeof(pvw->EVW_v[i].ECVW_v.ECAch); j ++) {
			pvw->EVW_v[i].ECVW_v.ECAch[j] = 'a' + i * 4 + j;
			Fadd32(pfml, ECACH, (char *)&(pvw->EVW_v[i].ECVW_v.ECAch[j]), 0);
		}
		for(j = 0; j < sizeof(pvw->EVW_v[i].EDVW_v.EDAch); j ++) {
			pvw->EVW_v[i].EDVW_v.EDAch[j] = 'z' - i * 2 - j;
			Fadd32(pfml, EDACH, (char *)&(pvw->EVW_v[i].EDVW_v.EDAch[j]), 0);
		}
	}

	printf("%s Send:\n", svc);
	Fprint32(pfml);

	if(tpcall(svc, (char *)pfml, 0L, (char **)&pfml, &len, TPNOTIME) == -1) {
		printf("tpcall %s failed (%s)\n", svc, tpstrerror(tperrno)); 
		return(-1);
    }

	memset(fi, 0, sizeof(fi));
	Fget32(pfml, FFI, 0, fi, 0);
	Fdel32(pfml, FFI, 0);
	printf("Recv(%ld):\n", len); 
	Fprint32(pfml);
	printf("FI(%.10s ... %s)\n", fi, fi + sizeof(fi) - 11);

	tpfree((char *)pfml);
  	tpfree((char *)pvw);
	return(0);
}

/*---------------------------------------------------------------------*/
main(int argc, char *argv[])
{
	char svc[40];

	if(argc < 2) {
		printf("%s svcname\n", argv[0]);
		printf("%s FLATVW | NESTVW | FLATFML | NESTFML | FMLVW | FFMLVW\n", argv[0]);
		exit(1);
	}

    if(tpinit((TPINIT *)NULL) == -1) {
        (void)fprintf(stderr, "Failed to join application  -- %s\n",
            tpstrerror(tperrno));
        (void)userlog("%s failed to join the application  -- %s\n",
            argv[0], tpstrerror(tperrno));
        (void)exit(1);
    }

	strcpy(svc, "BUFC");
	strcat(svc, argv[1]);
	if(! strcmp(argv[1], "FLATVW"))
		flatview(svc);		
	else if(! strcmp(argv[1], "NESTVW"))
		nestview(svc);
	else if(! strcmp(argv[1], "FLATFML"))
		flatfml(svc);
	else if(! strcmp(argv[1], "NESTFML"))
		nestfml(svc);
	else if(! strcmp(argv[1], "FMLVW"))
		fmlview(svc);
	else if(! strcmp(argv[1], "FFMLVW"))
		ffmlvw(svc);
	else
		printf("Invalid svcname(%s)\n", argv[1]);
	
	tpterm();
}

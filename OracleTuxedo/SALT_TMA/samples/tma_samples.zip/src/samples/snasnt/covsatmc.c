/*=====================================================================*/
/* Client zviewcln Requests Service(VIEW$$) From Server ZVIEWSRV On IBM*/
/*=====================================================================*/
#include <stdio.h>          /* UNIX */
#include <string.h>         /* UNIX */
#include <time.h>          /* UNIX */
/*#include <decimal.h>*/      /* TUXEDO */
#include <atmi.h>           /* TUXEDO */
#include <userlog.h>        /* TUXEDO */
#ifdef _TMFML32
#include <fml32.h>          /* TUXEDO */
#include <fml1632.h>        /* TUXEDO */
#else
#include <fml.h>            /* TUXEDO */
#include <Usysflds.h>       /* TUXEDO */
#endif
#include "bufview.h"        /* VIEW32 */
/* we use a generic structure since all 
** the views used have the same layout */
/*---------------------------------------------------------------------*/

/*---------------------------------------------------------------------*/

void disp(char *head, struct flat *pvw)
{
	int i;

	printf("%s:\n", head);
	printf("CH(%c)\n", pvw->Ach);
	printf("SH(%d)\n",  pvw->Bsh);
	printf("STR(%.40s)\n",  pvw->Cstr);
	printf("LO(%ld)\n",  pvw->Dlo);
	printf("CA(");
	for(i = 0; i < sizeof(pvw->Eca); i ++)
		printf("%02x", (unsigned char)pvw->Eca[i]);
	printf(")\n");
}

flatview(char *svc)
{
	char txt[32];
	int rc;
	int cd;
	long len;
	long revent;
	struct flat *req;
	struct flat1 *resp;

  	strcpy(txt, "flat");
  	req = (struct flat *)tpalloc("VIEW32", txt, sizeof(struct flat));
	if(req == NULL) {
        fprintf(stderr, "tpalloc %s failed (%s)\n", txt, tpstrerror(tperrno));
		return -1;
  	}
  	memset(req, 0, sizeof(struct flat));
    req->Ach = '1';
    req->Bsh = sizeof(struct flat);
    strcpy(req->Cstr, svc);
	if(sizeof(long) == 4 || getenv("LONG64_TO_S9_9_COMP"))
		req->Dlo = -999999999;
	else {
		strcat(req->Cstr, "1");
		req->Dlo = -999999999999999999;
	}
	memset(req->Eca, 1, sizeof(req->Eca));

	printf("%s:\n", svc);
	disp("Send", req);
	printf("\n");

	cd = tpconnect(svc, (char *)req, 0L, TPRECVONLY | TPSIGRSTRT);
	if(cd == -1) {
		fprintf(stderr, "Tpconnect failed: %s\n", tpstrerror(tperrno));
  		tpfree((char *)req);
		return -1;
	}

  	strcpy(txt, "flat1");
  	resp = (struct flat1 *)tpalloc("VIEW32", txt, sizeof(struct flat1));
	if(resp == NULL) {
        fprintf(stderr, "tpalloc %s failed (%s)\n", txt, tpstrerror(tperrno));
		return -1;
  	}
  	memset(resp, 0, sizeof(struct flat1));

	while(1) {
		rc = tprecv(cd, (char **)&resp, &len, TPSIGRSTRT, &revent);
		if(rc == -1) {
			if(tperrno != TPEEVENT) {
				fprintf(stderr, "Tprecv failed: %s\n", tpstrerror(tperrno));
				tpdiscon(cd);
  				tpfree((char *)req);
  				tpfree((char *)resp);
				return -1;
			}
			if(revent == TPEV_SVCSUCC) {
				break;
			} else {
				fprintf(stderr, "Tprecv recieved an unexpected event 0x%x. \n" , revent);
				tpdiscon(cd);
  				tpfree((char *)req);
  				tpfree((char *)resp);
				return -1;
			}
		}
		else
			printf("rc(%d)\n", rc);
	}

	sprintf(txt, "Recv(%d)", len);
  	disp(txt, (struct flat *)resp);
	printf("FI(%.10s ... %s)\n", resp->Ffi, resp->Ffi + sizeof(resp->Ffi) - 11);

  	tpfree((char *)req);
  	tpfree((char *)resp);

	return 0;
}

main(int argc, char *argv[])
{
	int rc;
	int sync;

	if(argc < 3) {
		printf("Usage: %s 0|2 service\n", argv[0]);
		exit(1);
	}

	sync = atoi(argv[1]);
	if(sync != 0 && sync != 2) {
		printf("Usage: %s 0|2 service\n", argv[0]);
		exit(1);
	}

    if(tpinit((TPINIT *)NULL) == -1) {
        (void)fprintf(stderr, "Failed to join application  -- %s\n",
            tpstrerror(tperrno));
        (void)userlog("%s failed to join the application  -- %s\n",
            argv[0], tpstrerror(tperrno));
        (void)exit(1);
    }

	if(sync == 2)
		tpbegin(0, 0);

	rc = flatview(argv[2]);
	if(rc == -1 && sync == 2 && tpabort(0) == -1) {
		(void)fprintf(stderr, "Tpabort failed: %s\n", tpstrerror(tperrno));
		(void)userlog("%s tpabort failed: %s\n", argv[0], tpstrerror(tperrno));
		(void)exit(1);
	}

	if(sync == 2 && tpcommit(0) == -1) {
		(void)fprintf(stderr, "Tpcommit failed: %s\n", tpstrerror(tperrno));
		(void)userlog("%s tpcommit failed: %s\n", argv[0], tpstrerror(tperrno));
		(void)exit(1);
	}

	(void)tpterm();
	(void)exit(0);
}

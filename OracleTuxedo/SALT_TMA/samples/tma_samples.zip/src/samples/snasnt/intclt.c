/*=====================================================================*/
/* Client zviewcln Requests Service(VIEW$$) From Server ZVIEWSRV On IBM*/
/*=====================================================================*/
#include <stdio.h>          /* UNIX */
#include <string.h>         /* UNIX */
#include <time.h>          /* UNIX */
/*#include <decimal.h>*/      /* TUXEDO */
#include <atmi.h>           /* TUXEDO */
#include <userlog.h>        /* TUXEDO */
#ifdef _TMFML32
#include <fml32.h>          /* TUXEDO */
#include <fml1632.h>        /* TUXEDO */
#else
#include <fml.h>            /* TUXEDO */
#include <Usysflds.h>       /* TUXEDO */
#endif
#include "intview.h"        /* VIEW32 */

/* we use a generic structure since all 
** the views used have the same layout */
/*---------------------------------------------------------------------*/
void disp(char *head, struct intv *pvw)
{
	int i;

	printf("%s:\n", head);
	printf("CH(%c)\n", pvw->Ach);
	printf("SH(%d)\n",  pvw->Bsh);
	printf("STR(%.40s)\n",  pvw->Cstr);
	printf("INT(%d)\n",  pvw->Vint);
	printf("LO(%ld)\n",  pvw->Dlo);
	printf("CA(");
	for(i = 0; i < sizeof(pvw->Eca); i ++)
		printf("%02x", (unsigned char)pvw->Eca[i]);
	printf(")\n");
}

intview(char *svc)
{
	char txt[32];
	struct intv *req;
	struct intv1 *resp;
	long len;

  	strcpy(txt, "intv");
  	req = (struct intv *)tpalloc("VIEW32", txt, sizeof(struct intv));
	if(req == NULL) {
        printf("tpalloc1 %s failed (%s)\n", txt, tpstrerror(tperrno));
		return(-1);
  	}
  	memset(req, 0, sizeof(struct intv));
	req->Ach = '1';
	req->Bsh = sizeof(struct intv);
	req->Vint = 98765;
	strcpy(req->Cstr, svc);
//	strcpy(req->Cstr, "FLATVW");
	if(sizeof(long) == 4 || getenv("LONG64_TO_S9_9_COMP"))
		req->Dlo = 999999999;
	else {
		strcat(req->Cstr, "1");
		req->Dlo = 999999999999999999;
	}
	memset(req->Eca, 1, sizeof(req->Eca));

	printf("%s:\n", svc);
	disp("Send", req);
	printf("\n");

  	strcpy(txt, "intv1");
  	resp = (struct intv1 *)tpalloc("VIEW32", txt, sizeof(struct intv1));
	if(resp == NULL) {
        printf("tpalloc 1 %s failed (%s)\n", txt, tpstrerror(tperrno));
		return(-1);
  	}
  	memset(resp, 0, sizeof(struct intv1));

/*
  if(tpcall(servicenn, (char *)req, 0L, (char **)&req, &len, 0L) == -1) {
*/
  	if(tpcall(svc, (char *)req, 0L, (char **)&resp, &len, TPNOTIME) == -1) {
		printf("tpcall %s failed (%s)\n", svc, tpstrerror(tperrno)); 
		return(-1);
    }

	sprintf(txt, "Recv(%ld)", len);
  	disp(txt, (struct intv *)resp);
	printf("FI(%.10s ... %s)\n", resp->Ffi, resp->Ffi + sizeof(resp->Ffi) - 11);

  	tpfree((char *)req);
  	tpfree((char *)resp);
	return(0);
}



/*---------------------------------------------------------------------*/
main(int argc, char *argv[])
{
	char svc[40];

	if(argc < 2) {
		printf("%s svcname\n", argv[0]);
		printf("%s INTVW\n", argv[0]);
		exit(1);
	}

    if(tpinit((TPINIT *)NULL) == -1) {
        (void)fprintf(stderr, "Failed to join application  -- %s\n",
            tpstrerror(tperrno));
        (void)userlog("%s failed to join the application  -- %s\n",
            argv[0], tpstrerror(tperrno));
        (void)exit(1);
    }

	strcpy(svc, "BUFC");
	strcat(svc, argv[1]);
	if(! strcmp(argv[1], "INTVW"))
		intview(svc);		
	else
			printf("Invalid svcname(%s)\n", argv[1]);
	
	tpterm();
}

#!/bin/ksh

crmlkoff -v -n $MAINFRAME:$PORTNUM SIMPLK
sleep 2
crmlkon -v -n $MAINFRAME:$PORTNUM SIMPLK
sleep 2
# crmdown -v -n $MAINFRAME:$PORTNUM

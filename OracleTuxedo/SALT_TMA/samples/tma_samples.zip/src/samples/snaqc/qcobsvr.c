/******************************************************************************
* qcobsvr.c
*	This tuxedo server calls the host tran for the QC tests.
*
* See also
*	<Related files, types, funcs, and libraries>.
*
* Copyright �1997, BEA Systems, Inc., all rights reserved.
*/


/* Identification */

#ifndef NO_IDENT
/* Identification */
static const char	File_c_id[] =
    "@(#)SNA $Header: /repos/tma/sample/snaqc/qcobsvr.c,v 1.1 2014/10/14 09:09:52 xixisun Exp $   ";
#endif

#include <sys/types.h>
#ifndef _WIN32
#include <unistd.h>
#endif
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>
#include <string.h>

/* Tuxedo Includes */
#include <atmi.h>

static char tranname[20] = "";
static long rspbufsz;
static long test_number;
static long number_of_sends;
static long number_of_exchanges;

QCSVR(TPSVCINFO *tpsvcinfo)
{
	int rCode;
	int cd;
	int i;
	int j;
	long len;
	long revent;
	long flags;
	char *rsp_buffer;
	char work[8];
	 struct {
        char    rbufsize[5];
        char    testnum[2];
        char    synclevel;
        char    localabort;
        char    remoteabort;
        char    sendnum;
        char    exchanges;
        char    sysid[4];
        char    debug;
        } temp;


	rCode = 0;
    	strcpy(tranname, tpsvcinfo->name);
    	tranname[0] = 'H';		/* Convert tranname to Host tranname */
	len = tpsvcinfo->len;
	memcpy(&temp, tpsvcinfo->data, sizeof(temp));
	memset(work, 0, sizeof(work));
	memcpy(work, temp.rbufsize, sizeof(temp.rbufsize));
	rspbufsz = atol(work);
	memset(work, 0, sizeof(work));
	memcpy(work, temp.testnum, sizeof(temp.testnum));
	test_number = atol(work);
	memset(work, 0, sizeof(work));
	work[0] = temp.sendnum;
	number_of_sends = atol(work);
	memset(work, 0, sizeof(work));
	work[0] = temp.exchanges;
	number_of_exchanges = atol(work);

	switch(test_number) {
/*	TPCALL 			*/
    	case 1: 
    	case 15: 
		if((rCode = tpcall( tranname, tpsvcinfo->data, len + 1,
			&(tpsvcinfo->data), &len, 0 )) == -1) {
		    userlog("Server got tpcall Error: %s\n", 
							tpstrerror(tperrno));
		    tpreturn(TPFAIL, 0, tpsvcinfo->data, len, 0);
                }
                else {
    		    tpreturn(TPSUCCESS, 0, tpsvcinfo->data, len - 1, 0);
                }
/*	TPCALL 	NOTRAN		*/
    	case 2: 
		if((rCode = tpcall( tranname, tpsvcinfo->data, len + 1,
			 &(tpsvcinfo->data), &len, TPNOTRAN )) == -1) {
		    userlog("Server got tpcall Error: %s\n", 
							tpstrerror(tperrno));
		    tpreturn(TPFAIL, 0, tpsvcinfo->data, len, 0);
                }
                else {
    		    tpreturn(TPSUCCESS, 0, tpsvcinfo->data, len - 1, 0);
                }
/*	TPACALL/TPGETRPLY 	*/
    	case 3: 
		if((cd = tpacall(tranname, tpsvcinfo->data, len + 1, 0)) == -1) {
		    userlog("Server got tpacall Error: %s\n", 
							tpstrerror(tperrno));
		    tpreturn(TPFAIL, 0, tpsvcinfo->data, len, 0);
                }
                else if (( rCode = tpgetrply(&cd,&tpsvcinfo->data, &len, 0)) ==
								-1) {
		    	userlog("Server got tpgetrply Error: %s\n", 
							tpstrerror(tperrno));
		    	tpreturn(TPFAIL, 0, tpsvcinfo->data, len, 0);
                    	}
		    else {
    		    	tpreturn(TPSUCCESS, 0, tpsvcinfo->data, len - 1, 0);
		    }
/*	TPACALL NOREPLY		*/
    	case 16: 
		if((cd = tpacall( tranname, tpsvcinfo->data, len + 1, 
						TPNOREPLY)) == -1) {
		    userlog("Server got tpacall Error: %s\n", 
							tpstrerror(tperrno));
		    tpreturn(TPFAIL, 0, tpsvcinfo->data, len, 0);
                }
                else {
    		    tpreturn(TPSUCCESS, 0, tpsvcinfo->data, len, 0);
                }
/*	TPCONNECT/TPSEND/TPRECV 		*/
	case 5:
	case 11:
		cd = tpconnect(tranname, NULL, 0, TPSENDONLY | TPSIGRSTRT);
		if(cd == -1) {
			userlog("Server got tpconnect Error: %s\n", 
							tpstrerror(tperrno));
        		tpreturn(TPFAIL, 0, tpsvcinfo->data, len, 0);
		}
		rsp_buffer = (char*)tpalloc("CARRAY", NULL, rspbufsz);
		for(i=0; i <= number_of_exchanges; i++) {
		    for(j=0; j < number_of_sends; j++) {
 			if(j == number_of_sends - 1)
				flags = TPRECVONLY|TPSIGRSTRT;
			else
				flags = TPSIGRSTRT;
			if(temp.debug == '1')
				userlog("Send number %d-%d\n", i + 1, j + 1);
		    	if((rCode = tpsend(cd, tpsvcinfo->data, len + 1, 
						flags, &revent)) == -1) {
				userlog("Server got tpsend Error: %s\n", 
							tpstrerror(tperrno));
				tpdiscon(cd);
				tpfree(rsp_buffer);
				tpreturn(TPFAIL, 0, tpsvcinfo->data, len, 0);
		    	}
		    }
		    if(temp.debug == '1')
		    	userlog("Recv number %d\n", i + 1);
		    if((rCode = tprecv(cd, &(rsp_buffer), &len, TPSIGRSTRT,
							&revent)) == -1) {
			if ((tperrno != TPEEVENT) || ((revent != TPEV_SVCSUCC)
					&& (revent != TPEV_SENDONLY))) {
				userlog("tprecv failed tperrno %s revent %ld\n",
					tpstrerror(tperrno), revent);
				tpdiscon(cd);
				tpfree(rsp_buffer);
				tpreturn(TPFAIL, 0, tpsvcinfo->data, 
							tpsvcinfo->len, 0);
			}
			if(temp.debug == '1')
		    		userlog("tprecv got -1, revent=%ld\n",
					revent);
		    }
		    else
		    	userlog("tprecv got zero return code, revent=%ld\n",
					revent);
		}
		tpfree(tpsvcinfo->data);
    		tpreturn(TPSUCCESS, 0, rsp_buffer, len, 0);
/*	TPCONNECT/TPSEND 		*/
	case 6:
		rsp_buffer = (char*)tpalloc("CARRAY", NULL, rspbufsz);
		cd = tpconnect(tranname, NULL, 0, TPSENDONLY|TPSIGRSTRT);
		if(cd == -1) {
			userlog("Server got tpconnect Error: %s\n", 
							tpstrerror(tperrno));
			tpfree(rsp_buffer);
        		tpreturn(TPFAIL, 0, tpsvcinfo->data, len, 0);
		}
		if((rCode = tpsend(cd, tpsvcinfo->data, len + 1, 
				TPRECVONLY|TPSIGRSTRT, &revent)) == -1) {
			userlog("Server got tpsend Error: %s\n", 
							tpstrerror(tperrno));
			tpfree(rsp_buffer);
			tpdiscon(cd);
			tpreturn(TPFAIL, 0, tpsvcinfo->data, len, 0);
		}
		if((rCode = tprecv(cd, &(rsp_buffer), &len, TPSIGRSTRT,
							&revent)) == -1) {
			if ((tperrno != TPEEVENT) || (revent != TPEV_SVCSUCC))
			{
			    userlog("tprecv failed tperrno %s revent %ld\n",
					tpstrerror(tperrno), revent);
			    tpdiscon(cd);
			    tpfree(rsp_buffer);
			    tpreturn(TPFAIL, 0, tpsvcinfo->data, tpsvcinfo->len,
									 0);
			}
			if(temp.debug == '1')
		   	    userlog("tprecv got -1 return code, revent=%ld\n",
					revent);
		}
		else
		    	userlog("tprecv got zero return code, revent=%ld\n",
					revent);
		tpfree(rsp_buffer);
    		tpreturn(TPSUCCESS, 0, tpsvcinfo->data, tpsvcinfo->len, 0);
/*	TPCONNECT/TPRECV 		*/
	case 7:
		cd = tpconnect(tranname, NULL, 0, TPRECVONLY|TPSIGRSTRT);
		if(cd == -1) {
			userlog("Server got tpconnect Error: %s\n", 
							tpstrerror(tperrno));
        		tpreturn(TPFAIL, 0, tpsvcinfo->data, len, 0);
		}
		if((rCode = tprecv(cd, &(tpsvcinfo->data), &len, TPSIGRSTRT, 
							&revent)) == -1) {
			if ((tperrno != TPEEVENT) || (revent != TPEV_SVCSUCC)) {
				userlog("tprecv failed tperrno %s revent %ld\n",
					tpstrerror(tperrno), revent);
				tpdiscon(cd);
				if(len == 0)
					len = 100;
				tpreturn(TPFAIL, 0, tpsvcinfo->data, len, 0);
			}
		}
    		tpreturn(TPSUCCESS, 0, tpsvcinfo->data, len - 1, 0);
/*	TPCONNECT With Data/TPRECV 		*/
	case 8:
	case 14:
		flags = TPRECVONLY|TPSIGRSTRT;
		cd = tpconnect(tranname, tpsvcinfo->data, len + 1, flags);
		if(cd == -1) {
			userlog("Server got tpconnect Error: %s\n", 
							tpstrerror(tperrno));
        		tpreturn(TPFAIL, 0, tpsvcinfo->data, len, 0);
		}
		if((rCode = tprecv(cd, &(tpsvcinfo->data), &len, TPSIGRSTRT, 
							&revent)) == -1) {
			if ((tperrno != TPEEVENT) || ((revent != TPEV_SVCSUCC)
					&& (revent != TPEV_SENDONLY))) {
				userlog("tprecv failed tperrno %s revent %ld\n",
					tpstrerror(tperrno), revent);
				tpdiscon(cd);
				if(len == 0)
					len = 100;
				tpreturn(TPFAIL, 0, tpsvcinfo->data, len, 0);
			}
		}
    		tpreturn(TPSUCCESS, 0, tpsvcinfo->data, len - 1, 0);
	default: 
		userlog("Bad CASE option = %d\n", test_number);
		tpreturn(TPFAIL, 0, tpsvcinfo->data, len, 0);
		
	}
}

int
tpsvrinit(int argc, char **argv)
{
    userlog("%s started...", argv[0]);

    if (tpopen() == -1)
    {
        userlog("Error connecting to TS Resource Manager.");
    }

    return 0;
}

void tpsvrdone()
{
    userlog("tpsvrdone");
    if (tpclose() == -1)
        userlog("Error closing connection to TS Resource Manager.");
}

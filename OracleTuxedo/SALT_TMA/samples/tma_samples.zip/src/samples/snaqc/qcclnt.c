/******************************************************************************
* qcclnt.c
*   This tuxedo client drives the QC test servers.
*
* See also
*   <Related files, types, funcs, and libraries>.
*
* Copyright �1997, BEA Systems, Inc., all rights reserved.
*/


/* Identification */

#ifndef NO_IDENT
/* Identification */
static const char   File_c_id[] =
    "@(#)SNA $Header: /repos/tma/sample/snaqc/qcclnt.c,v 1.1 2014/10/14 09:10:04 xixisun Exp $   ";
#endif

#include <sys/types.h>
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>
#include <string.h>

/* Tuxedo Includes */
#include <atmi.h>
#include <userlog.h>

static char tranname[20] = "";
static long synclvl = 0;
static long loop_count = 1;
static long reqbufsz = 100;
static long rspbufsz = 100;

static long debug = 0;

/*
  returns n for -n type options
  sets global myoptarg to value associated
  with -n. myoptarg wll be incorrect for
  opts which do not have an arg.
  caller should ignore value
*/
static char *myoptarg = 0;
int optget(int ct, char * cl[])
{
  int argct = 0;
  int opt   = 0;
  for(argct++;argct < ct;argct++)
    {
      if((char)*(cl[argct]) == (char)'-')
        {
          *(cl[argct]) = (char)' ';
          myoptarg = cl[argct+1];
          opt = (char)*((cl[argct])+1);
          return opt;
        }
    }
  return -1;
}

main(int argc, char **argv)
{
    int rCode;
    int c = 0;
    int i;
    long len;
    long test_number = 1;
    char line[80];
    struct {
    char    rbufsize[5];
    char    testnum[2];
    char    synclevel;
    char    localabort;
    char    remoteabort;
    char    sendnum;
    char    exchanges;
    char    sysid[4];
    char    debug;
    } temp;
    char *buffer;
    char** tmpArgv = argv;

    rCode = 0;
    proc_name = argv[0];
    memset(&temp, '0', sizeof(temp));
    memset(temp.sysid, ' ', sizeof(temp.sysid));
    temp.sendnum = '1';
    temp.exchanges = '0';
/*  while ((c = getopt(argc, tmpArgv, "d:c:g:n:l:r:t:s:o:i:x:S:h")) != -1) */
    while ((c = optget(argc, tmpArgv)) != -1)
    {
        switch(c)
        {
            case 't' :
                strcpy(tranname, myoptarg);
                break;
            case 'd' :
                temp.debug = myoptarg[0];
                debug = strtol(myoptarg, (char**)NULL, 0);
                break;
            case 'g' :
                temp.sendnum = myoptarg[0];
                break;
            case 'l' :
                temp.localabort = myoptarg[0];
                break;
            case 'r' :
                temp.remoteabort = myoptarg[0];
                break;
            case 'x' :
                temp.exchanges = myoptarg[0];
                break;
            case 'n' :
                test_number = strtol(myoptarg, (char**)NULL, 0);
                break;
            case 's' :
                synclvl = strtol(myoptarg, (char**)NULL, 0);
                temp.synclevel = myoptarg[0];
                break;
            case 'c' :
                loop_count = strtol(myoptarg, (char**)NULL, 0);
                break;
            case 'i' :
                rspbufsz = strtol(myoptarg, (char**)NULL, 0);
                break;
            case 'o' :
                reqbufsz = strtol(myoptarg, (char**)NULL, 0);
                break;
            case 'S' :
                memcpy(temp.sysid, myoptarg, strlen(myoptarg));
                break;
            case 'h' :
                printf("\nUsage is:\n");
                printf("%6.6s -c n      [Loop count (default=%d)]\n", argv[0], loop_count);
                printf("       -t xxxxxxxxx     [Tran name]\n");
                printf("       -s n         [Sync Level (default=%d)]\n", synclvl);
                printf("       -o n         [Request buffer size (default=%d)]\n", reqbufsz);
                printf("       -i n         [Response buffer size (default=%d)]\n", rspbufsz);
                printf("       -n n         [Test Number (default=1)]\n");
                printf("       -l n         [Local abort {0 normal/1 abort/2 commit}(default=0)]\n");
                printf("       -r n         [Remote abort {0 normal/1 abort/2 commit}(default=0)]\n");
                printf("       -g n         [Number of sends prior to recv (default=1)]\n");
                printf("       -x n         [Exchange count for DTP (default=1)]\n");
                printf("       -S xxxx      [Sysid for inbound test]\n");
                printf("       -d n         [Print debug info (default=0)]\n");
                printf("       -h           [Help]\n\n");
                exit(1);
            default:
                break;
        }
    }

    if(tpinit(0) == -1) {
        fprintf(stderr, "%s - tpinit failed - %s\n", argv[0], tpstrerror(tperrno));
        exit(1);
    }

    sprintf(temp.rbufsize, "%5.5d", rspbufsz);
    sprintf(line , "%2.2d", test_number);
    memcpy(temp.testnum, line, 2);
    if(temp.debug == '1') {
        printf("client %s started\n", argv[0]);
        printf("transaction id=[%s]\n", tranname);
        printf("Sync level=%d\n", synclvl);
        printf("Loop count=%d\n", loop_count);
        printf("Request buffer size=%d\n", reqbufsz);
        printf("Response buffer size=%d\n", rspbufsz);
        printf("Test number is=%d\n", test_number);
        printf("Local Abort is=%c\n", temp.localabort);
        printf("Remote Abort is=%c\n", temp.remoteabort);
        printf("Number of sends is=%c\n", temp.sendnum);
        printf("Number of exchanges is=%c\n", temp.exchanges);
        printf("SYSID is=[%4.4s]\n", temp.sysid);
    }

    for(i=0; i < loop_count; i++) {
        buffer = (char*)tpalloc("STRING", NULL, reqbufsz + 1);
        memset(buffer, 'a', reqbufsz);
        memcpy(buffer, &temp, sizeof(temp));
        if(temp.debug == '1')
            printf("buffer=[%20.20s...%c]\n", buffer, buffer[reqbufsz -1]);
        if(synclvl)
            if(tpbegin(50, 0) == -1) {
                fprintf(stderr, "tpbegin failed - %s\n", tpstrerror(tperrno));
                tpterm();
                exit(1);
            }

        rCode = tpcall( tranname, buffer, 0, &buffer, &len, 0 );
        if(rCode == -1) {
            fprintf(stderr, "Request %d got TPCALL Error: %s\n", i,
                tpstrerror(tperrno));
            if(synclvl)
                if(tpabort(0) == -1) {
                    fprintf(stderr, "tpabort failed - %s\n", tpstrerror(tperrno));
                    tpterm();
                    exit(1);
                }
            tpterm();
            exit(1);
        }

        if(temp.debug == '1')
            printf("Received response of %d bytes\n", len);

        if(memcmp(buffer, &temp, sizeof(temp)) &&
            memcmp(buffer, "Buffer Not", strlen("Buffer Not")) &&
            buffer[18] != 'A')
        {
            printf("Request %d got bad response %20.20s...%c\n",
                i, buffer, buffer[len - 2]);
            if(synclvl)
                if(tpabort(0) == -1) {
                    fprintf(stderr, "tpabort failed - %s\n", tpstrerror(tperrno));
                    tpterm();
                    exit(1);
                }
            tpterm();
            exit(1);
        }

        printf("Request %d got good response %30.30s...%c\n",
            i, buffer, buffer[len - 2]);

        if(synclvl) {
            if(temp.localabort == '1') {
                if(temp.debug == '1')
                    printf("tpabort\n");
                if(tpabort(0) == -1) {
                    fprintf(stderr, "tpabort failed - %s\n", tpstrerror(tperrno));
                    tpterm();
                    exit(1);
                }
            }
            else {
                if(temp.debug == '1')
                    printf("tpcommit\n");
                if(tpcommit(0) == -1) {
                    fprintf(stderr, "tpcommit failed - %s\n", tpstrerror(tperrno));
                    tpterm();
                    exit(1);
                }
            }
        }

        tpfree(buffer);
    }
    tpterm();

    return(0);
}

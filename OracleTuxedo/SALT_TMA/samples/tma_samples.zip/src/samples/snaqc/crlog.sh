#!/bin/sh

tmadmin << !
crdl -z $APPDIR/TLOG
crlg -m SITE1
!

/******************************************************************************
* qcibsvr.c
*	This tuxedo server is called from the host for the QC tests.
*
* See also
*	<Related files, types, funcs, and libraries>.
*
* Copyright �1997, BEA Systems, Inc., all rights reserved.
*/


/* Identification */

#ifndef NO_IDENT
/* Identification */
static const char	File_c_id[] =
    "@(#)SNA $Header: /repos/tma/sample/snaqc/qcibsvr.c,v 1.1 2014/10/14 09:10:10 xixisun Exp $   ";
#endif

#include <sys/types.h>
#ifndef _WIN32
#include <unistd.h>
#endif
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>
#include <string.h>

/* Tuxedo Includes */
#include <atmi.h>

static char tranname[20] = "";
static long rspbufsz;
static long test_number;
static long number_of_sends;
static long number_of_exchanges;
static long flags;

QCSVR(TPSVCINFO *tpsvcinfo)
{
	int rCode;
	int cd;
	int i;
	int j;
	long len;
	long outlen;
	long minlen;
	long revent;
        char work[8];
	char *rsp_buffer;
	struct {
	char    rbufsize[5];
        char    testnum[2];
        char    synclevel;
        char    localabort;
        char    remoteabort;
        char    sendnum;
        char    exchanges;
        char    sysid[4];
        char    debug;
	} temp;

	rCode = 0;
	len = tpsvcinfo->len;
	memcpy(&temp, tpsvcinfo->data, sizeof(temp));
	memset(work, 0, sizeof(work));
	memcpy(work, temp.rbufsize, sizeof(temp.rbufsize));
	rspbufsz = atol(work);
	memset(work, 0, sizeof(work));
	memcpy(work, temp.testnum, sizeof(temp.testnum));
	test_number = atol(work);
	memset(work, 0, sizeof(work));
	work[0] = temp.sendnum;
	number_of_sends = atol(work);
	memset(work, 0, sizeof(work));
	work[0] = temp.exchanges;
	number_of_exchanges = atol(work);

	outlen = rspbufsz + 1;
	rsp_buffer = tpalloc("CARRAY", NULL,  outlen);
	memset(rsp_buffer, ' ', outlen -1);
	minlen = rspbufsz;
	if(len < rspbufsz)
		minlen = len;
	if(temp.debug == '1') {
		userlog("rspbufsz=%d, testnum=%d, sendnum=%d, exchanges=%d\n",
		   rspbufsz, test_number, number_of_sends, number_of_exchanges);
		userlog("input flags=0x%x, service name=%s\n", tpsvcinfo->flags,
				 tpsvcinfo->name);
	}

	switch(test_number) {
/*	TPCALL 			*/
    	case 1: 
    	case 15: 
/*	TPCALL 	NOTRAN		*/
    	case 2: 
/*	TPACALL/TPGETRPLY 	*/
    	case 3: 
		/* TRANSLATE TO UPPER */
		for(i = 0; i < len; i++)
			tpsvcinfo->data[i] = toupper(tpsvcinfo->data[i]);
		memcpy(rsp_buffer, tpsvcinfo->data, minlen);
		tpfree(tpsvcinfo->data);
    		tpreturn(TPSUCCESS, 0, rsp_buffer, outlen, 0);
/*	TPACALL NOREPLY		*/
    	case 4: 
    	case 16: 
		userlog("Transaction %s processed\n", tpsvcinfo->name);
		userlog("Data = [%s]\n", tpsvcinfo->data);
    		tpreturn(TPSUCCESS, 0, NULL, 0, 0);
/*	TPCONNECT/TPSEND/TPRECV 		*/
	case 5:
	case 11:
		cd = tpsvcinfo->cd;
		if(temp.debug == '1')
			userlog("case 5 started\n");
		for(j = 0; j <= number_of_exchanges; j++) {
		    for(i=0; i < number_of_sends - 1; i++) {
			if(tpsvcinfo->flags & TPRECVONLY) {
			    if(temp.debug == '1') {
				userlog("case 5 tprecv started\n");
				revent = 0;
			    }
			    if((rCode = tprecv(cd, &(tpsvcinfo->data), &len, 
					TPSIGRSTRT, &revent)) == -1) {
                            if ((tperrno != TPEEVENT) 
					|| ((revent != TPEV_SVCSUCC)
                                        && (revent != TPEV_SENDONLY))) {
                                userlog("tprecv failed tperrno %s revent %ld\n",
                                        tpstrerror(tperrno), revent);
                                if(len == 0)
                                        len = 100;
                                tpreturn(TPFAIL, 0, tpsvcinfo->data, len, 0);
                            }
			    if(temp.debug == '1')
				userlog("case 5 tprecv got -1, revent=%ld\n",
								revent);
                            }
                        }
			if(temp.debug == '1')
				userlog("case 5 received number %d\n", i+1);
                    }
		    if(j == 0)
			number_of_sends++;
		    /* TRANSLATE TO UPPER */
		    if(temp.debug == '1')
			userlog("case 5 input data =[%20.20s]\n", 
							tpsvcinfo->data);
		    for(i = 0; i < minlen; i++)
			rsp_buffer[i] = toupper(tpsvcinfo->data[i]);
		    if(temp.debug == '1')
			userlog("case 5 sent number %d\n", j+1);
		    if(j == number_of_exchanges)
			flags = TPSIGRSTRT;
		    else
			flags = TPRECVONLY|TPSIGRSTRT;
		    if(temp.debug == '1')
			userlog("case 5 flags = 0x%x\n", flags);
		    if((rCode = tpsend(cd, rsp_buffer, outlen, 
                               			flags, &revent)) == -1) {
                        	userlog("Server got tpsend Error: %s\n", 
                                                        tpstrerror(tperrno));
                        	tpreturn(TPFAIL, 0, rsp_buffer, len, 0);
                    }
                }
                tpfree(tpsvcinfo->data);
                tpfree(rsp_buffer);
                tpreturn(TPSUCCESS, 0, NULL, 0, 0);
/*	TPCONNECT/TPSEND 		*/
	case 6:
	case 12:
		userlog("Transaction %s processed\n", tpsvcinfo->name);
		userlog("Data = [%s]\n", tpsvcinfo->data);
    		tpreturn(TPSUCCESS, 0, NULL, 0, 0);
/*	TPCONNECT/TPRECV 		*/
	case 7:
	case 13:
		len = 100;
		tpsvcinfo->data = tprealloc("CARRAY", len);
		strcpy(tpsvcinfo->data, "This is a generated response");
    		tpreturn(TPSUCCESS, 0, tpsvcinfo->data, len, 0);
/*	TPCONNECT With Data/TPRECV 		*/
	case 8:
	case 14:
		/* TRANSLATE TO UPPER */
		for(i = 0; i < len; i++)
			rsp_buffer[i] = toupper(tpsvcinfo->data[i]);
                tpfree(tpsvcinfo->data);
    		tpreturn(TPSUCCESS, 0, rsp_buffer, outlen, 0);
		cd = tpconnect(tranname, tpsvcinfo->data, len, TPRECVONLY);
	default: 
		userlog("Bad CASE option = %d\n", test_number);
		tpreturn(TPFAIL, 0, tpsvcinfo->data, len, 0);
		
	}
}

int
tpsvrinit(int argc, char **argv)
{
    userlog("%s started...", argv[0]);

    if (tpopen() == -1)
    {
        userlog("Error connecting to TS Resource Manager.");
    }

    return 0;
}

void tpsvrdone()
{
    userlog("tpsvrdone");
    if (tpclose() == -1)
        userlog("Error closing connection to TS Resource Manager.");
}

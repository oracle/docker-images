#!/bin/ksh
# set -x

logerr()
{ 
	ts=`date +"%y/%m/%d %H:%M:%S"`
	echo "\n$ts $1 failed"
	exit 1
}

logstep()
{
	ts=`date +"%y/%m/%d %H:%M:%S"`
	echo "\n$ts $1 passed"
}

runCases()
{
	kernel=`uname -s`
	if [ $kernel = Linux -a `uname -m` = s390x ]
	then
		kernel=zLinux
	fi

	case $kernel in
		Linux | HP-UX | AIX | SunOS)
			cases=" \
				snaqc \
				snasnt \
			"
			;;
		*)
			echo "Invalid OS"			
			;;
	esac		

	for j in $cases
	do
		runcase.sh $j || logerr "runcase.sh $j"
    	logstep "runcase.sh $j"
	done
}


## MAIN

cd tma_case
runCases

exit 0
